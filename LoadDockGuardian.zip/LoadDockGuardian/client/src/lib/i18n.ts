// Internationalization utility for multilingual support

type Language = 'en' | 'es' | 'fr' | 'de' | 'zh';

interface Translations {
  [key: string]: {
    [key in Language]?: string;
  };
}

// All translatable content goes here
const translations: Translations = {
  // General UI
  "app.title": {
    en: "DockSafe",
    es: "DockSafe",
    fr: "DockSafe",
    de: "DockSafe",
    zh: "码头安全"
  },
  "app.description": {
    en: "Loading Dock Safety Management System",
    es: "Sistema de gestión de seguridad de muelles de carga",
    fr: "Système de gestion de la sécurité des quais de chargement",
    de: "Laderampen-Sicherheitsmanagementsystem",
    zh: "装卸码头安全管理系统"
  },

  // Kiosk Mode
  "kiosk.title": {
    en: "Driver Check-In Kiosk",
    es: "Quiosco de registro de conductores",
    fr: "Kiosque d'enregistrement des chauffeurs",
    de: "Fahrer Check-In Kiosk",
    zh: "驾驶员登记处"
  },
  "kiosk.welcome": {
    en: "Welcome to the DockSafe driver check-in system. Please provide your information to proceed.",
    es: "Bienvenido al sistema de registro de conductores DockSafe. Por favor, proporcione su información para continuar.",
    fr: "Bienvenue dans le système d'enregistrement des chauffeurs DockSafe. Veuillez fournir vos informations pour continuer.",
    de: "Willkommen beim DockSafe Fahrer-Check-In-System. Bitte geben Sie Ihre Informationen ein, um fortzufahren.",
    zh: "欢迎使用DockSafe驾驶员登记系统。请提供您的信息以继续。"
  },
  
  // Driver Info Form
  "driver.info": {
    en: "Driver Information",
    es: "Información del conductor",
    fr: "Informations sur le chauffeur",
    de: "Fahrerinformationen",
    zh: "驾驶员信息"
  },
  "driver.name": {
    en: "Driver Name",
    es: "Nombre del conductor",
    fr: "Nom du chauffeur",
    de: "Name des Fahrers",
    zh: "驾驶员姓名"
  },
  "driver.company": {
    en: "Company Name",
    es: "Nombre de la empresa",
    fr: "Nom de l'entreprise",
    de: "Firmenname",
    zh: "公司名称"
  },
  "driver.phone": {
    en: "Phone Number",
    es: "Número de teléfono",
    fr: "Numéro de téléphone",
    de: "Telefonnummer",
    zh: "电话号码"
  },
  "driver.truck": {
    en: "Truck Number",
    es: "Número de camión",
    fr: "Numéro de camion",
    de: "LKW-Nummer",
    zh: "卡车号码"
  },
  "driver.trailer": {
    en: "Trailer Number",
    es: "Número de remolque",
    fr: "Numéro de remorque",
    de: "Anhängernummer",
    zh: "拖车号码"
  },
  "driver.type": {
    en: "Trailer Type",
    es: "Tipo de remolque",
    fr: "Type de remorque",
    de: "Anhängertyp",
    zh: "拖车类型"
  },
  "driver.type.liveLoad": {
    en: "Live Load",
    es: "Carga en vivo",
    fr: "Chargement en direct",
    de: "Live-Beladung",
    zh: "即时装载"
  },
  "driver.type.dropTrailer": {
    en: "Drop Trailer",
    es: "Remolque desenganchado",
    fr: "Remorque dételée",
    de: "Abstellanhänger",
    zh: "脱钩拖车"
  },
  
  // Dock Selection
  "dock.selection": {
    en: "Dock Selection",
    es: "Selección de muelle",
    fr: "Sélection du quai",
    de: "Rampenauswahl",
    zh: "码头选择"
  },
  "dock.select": {
    en: "Select Dock Number",
    es: "Seleccione el número de muelle",
    fr: "Sélectionnez le numéro de quai",
    de: "Wählen Sie die Rampennummer",
    zh: "选择码头号码"
  },
  "dock.shipping": {
    en: "Shipping",
    es: "Envío",
    fr: "Expédition",
    de: "Versand",
    zh: "运输"
  },
  "dock.exportShipping": {
    en: "Export Shipping",
    es: "Envío de exportación",
    fr: "Expédition d'exportation",
    de: "Exportversand",
    zh: "出口运输"
  },
  "dock.receiving": {
    en: "Receiving",
    es: "Recepción",
    fr: "Réception",
    de: "Empfang",
    zh: "接收"
  },
  "dock.exportReceiving": {
    en: "Export Receiving",
    es: "Recepción de exportación",
    fr: "Réception d'exportation",
    de: "Exportempfang",
    zh: "出口接收"
  },
  
  // Safety Check
  "safety.check": {
    en: "Safety Check",
    es: "Comprobación de seguridad",
    fr: "Vérification de sécurité",
    de: "Sicherheitsprüfung",
    zh: "安全检查"
  },
  "safety.confirmation": {
    en: "Safety Confirmation",
    es: "Confirmación de seguridad",
    fr: "Confirmation de sécurité",
    de: "Sicherheitsbestätigung",
    zh: "安全确认"
  },
  "safety.confirmation.message": {
    en: "By completing this check-in, I confirm that all safety protocols have been followed, including:",
    es: "Al completar este registro, confirmo que se han seguido todos los protocolos de seguridad, incluyendo:",
    fr: "En complétant cet enregistrement, je confirme que tous les protocoles de sécurité ont été suivis, notamment:",
    de: "Durch Abschluss dieser Anmeldung bestätige ich, dass alle Sicherheitsprotokolle eingehalten wurden, einschließlich:",
    zh: "通过完成此登记，我确认已遵循所有安全协议，包括："
  },
  "safety.item.wheelChocks": {
    en: "Wheel Chocks in Place",
    es: "Calzos de ruedas en su lugar",
    fr: "Cales de roues en place",
    de: "Radkeile angebracht",
    zh: "车轮止动器到位"
  },
  "safety.item.restraint": {
    en: "Restraint Engaged",
    es: "Sujeción activada",
    fr: "Dispositif de retenue engagé",
    de: "Feststellbremse angezogen",
    zh: "约束装置已启用"
  },
  "safety.item.signals": {
    en: "Signal Lights Active",
    es: "Luces de señalización activas",
    fr: "Feux de signalisation actifs",
    de: "Signallichter aktiv",
    zh: "信号灯已激活"
  },
  "safety.item.vehicle": {
    en: "Vehicle Turned Off",
    es: "Vehículo apagado",
    fr: "Véhicule éteint",
    de: "Fahrzeug ausgeschaltet",
    zh: "车辆已关闭"
  },
  "safety.item.gladHand": {
    en: "Glad Hand Lock Placed",
    es: "Bloqueo de manos colocado",
    fr: "Verrou de main joyeuse placé",
    de: "Luftleitungssperre angebracht",
    zh: "气管锁已放置"
  },
  "safety.item.jackStand": {
    en: "Trailer Jack Stand Placed",
    es: "Soporte del remolque colocado",
    fr: "Support de remorque placé",
    de: "Anhängerstütze angebracht",
    zh: "拖车千斤顶已放置"
  },
  "safety.summary": {
    en: "Your Information",
    es: "Su información",
    fr: "Vos informations",
    de: "Ihre Informationen",
    zh: "您的信息"
  },
  
  // Buttons
  "button.next": {
    en: "Next",
    es: "Siguiente",
    fr: "Suivant",
    de: "Weiter",
    zh: "下一步"
  },
  "button.back": {
    en: "Back",
    es: "Atrás",
    fr: "Retour",
    de: "Zurück",
    zh: "返回"
  },
  "button.complete": {
    en: "Complete Check-In",
    es: "Completar registro",
    fr: "Terminer l'enregistrement",
    de: "Check-In abschließen",
    zh: "完成登记"
  },
  
  // Notifications
  "notify.missingInfo": {
    en: "Missing Information",
    es: "Información faltante",
    fr: "Informations manquantes",
    de: "Fehlende Informationen",
    zh: "缺少信息"
  },
  "notify.requiredFields": {
    en: "Please fill out all required fields",
    es: "Por favor, complete todos los campos obligatorios",
    fr: "Veuillez remplir tous les champs obligatoires",
    de: "Bitte füllen Sie alle Pflichtfelder aus",
    zh: "请填写所有必填字段"
  },
  "notify.selectDock": {
    en: "Please select a dock number",
    es: "Por favor, seleccione un número de muelle",
    fr: "Veuillez sélectionner un numéro de quai",
    de: "Bitte wählen Sie eine Rampennummer",
    zh: "请选择一个码头号码"
  },
  "notify.checkInComplete": {
    en: "Check-In Complete",
    es: "Registro completado",
    fr: "Enregistrement terminé",
    de: "Check-In abgeschlossen",
    zh: "登记完成"
  },
  "notify.successfulCheckIn": {
    en: "You have been successfully checked in",
    es: "Se ha registrado correctamente",
    fr: "Vous avez été enregistré avec succès",
    de: "Sie wurden erfolgreich angemeldet",
    zh: "您已成功登记"
  },
  "notify.checkInProcessed": {
    en: "Check-In Processed",
    es: "Registro procesado",
    fr: "Enregistrement traité",
    de: "Check-In verarbeitet",
    zh: "登记已处理"
  },
  "notify.driverCheckedIn": {
    en: "has been checked in to dock",
    es: "ha sido registrado en el muelle",
    fr: "a été enregistré au quai",
    de: "wurde an der Rampe angemeldet",
    zh: "已登记到码头"
  }
};

// Current selected language
let currentLanguage: Language = 'en';

// Get translation for a specific key
export function t(key: string, lang?: Language): string {
  const selectedLang = lang || currentLanguage;
  
  if (translations[key]?.[selectedLang]) {
    return translations[key][selectedLang] as string;
  }
  
  // Fallback to English
  if (translations[key]?.en) {
    return translations[key].en as string;
  }
  
  // If no translation is found, return the key
  return key;
}

// Set the current language
export function setLanguage(lang: Language): void {
  currentLanguage = lang;
}

// Get current language
export function getLanguage(): Language {
  return currentLanguage;
}

// List of supported languages
export const supportedLanguages = [
  { code: 'en', name: 'English' },
  { code: 'es', name: 'Español' },
  { code: 'fr', name: 'Français' },
  { code: 'de', name: 'Deutsch' },
  { code: 'zh', name: '中文' }
] as const;

export type SupportedLanguage = (typeof supportedLanguages)[number]['code'];