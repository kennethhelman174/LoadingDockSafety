import React from 'react';
import MainLayout from '@/components/layout/MainLayout';
import DriverKiosk from '@/components/kiosk/DriverKiosk';
import { useToast } from '@/hooks/use-toast';

interface DriverInfo {
  driverName: string;
  companyName: string;
  truckNumber: string;
  trailerNumber: string;
  phoneNumber: string;
  dockNumber: string;
  trailerType: 'liveLoad' | 'dropTrailer';
}

const KioskMode: React.FC = () => {
  const { toast } = useToast();

  const handleKioskComplete = (driverInfo: DriverInfo) => {
    // In a real application, we would submit this data to the server
    console.log('Driver check-in completed:', driverInfo);
    
    toast({
      title: "Check-In Processed",
      description: `${driverInfo.driverName} has been checked in to dock ${driverInfo.dockNumber}`,
    });
  };

  return (
    <MainLayout title="Driver Check-In Kiosk" description="Self-service check-in for truck drivers">
      <div className="max-w-5xl mx-auto px-4 py-8">
        <h1 className="text-3xl font-bold mb-6 text-center">Driver Self-Service Kiosk</h1>
        <p className="text-center mb-8 text-lg text-gray-600 dark:text-gray-400">
          Welcome to the DockSafe driver check-in system. Please provide your information to proceed.
        </p>
        
        <DriverKiosk onComplete={handleKioskComplete} />
      </div>
    </MainLayout>
  );
};

export default KioskMode;