import React from 'react';
import MainLayout from '@/components/layout/MainLayout';
import SafetyPerformanceAnalytics from '@/components/analytics/SafetyPerformanceAnalytics';

const Analytics: React.FC = () => {
  return (
    <MainLayout title="Safety Analytics">
      <SafetyPerformanceAnalytics />
    </MainLayout>
  );
};

export default Analytics;