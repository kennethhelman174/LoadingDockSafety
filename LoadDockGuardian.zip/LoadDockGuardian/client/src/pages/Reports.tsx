import React, { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import MainLayout from '@/components/layout/MainLayout';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { 
  Table, 
  TableBody, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from '@/components/ui/table';
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from '@/components/ui/tabs';
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  LineChart,
  Line,
  PieChart,
  Pie,
  Cell,
  Legend,
} from 'recharts';
import { 
  Calendar, 
  CheckCircle, 
  AlertTriangle, 
  AlertCircle,
  FileBarChart,
  ClipboardList,
  TrendingUp,
  History,
  Calendar as CalendarIcon
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { 
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue 
} from '@/components/ui/select';
import { Progress } from '@/components/ui/progress';

const Reports: React.FC = () => {
  const [timeframe, setTimeframe] = useState<string>('month');
  const [activeTab, setActiveTab] = useState<string>('metrics');

  // Fetch safety metrics
  const { data: safetyMetrics, isLoading: isLoadingMetrics } = useQuery({
    queryKey: ['/api/safety-metrics'],
  });

  // Fetch activity logs
  const { data: activityLogs = [], isLoading: isLoadingLogs } = useQuery({
    queryKey: ['/api/activity-log'],
  });

  // Fetch incidents 
  const { data: incidents = [], isLoading: isLoadingIncidents } = useQuery({
    queryKey: ['/api/incidents'],
  });

  // Sample data for charts (based on activity logs and metrics)
  const getPerformanceData = () => {
    // We'd normally calculate this from real data
    return [
      { name: 'Week 1', safetyScore: 90, completionRate: 85 },
      { name: 'Week 2', safetyScore: 92, completionRate: 87 },
      { name: 'Week 3', safetyScore: 88, completionRate: 84 },
      { name: 'Week 4', safetyScore: 91, completionRate: 88 },
    ];
  };

  const getIncidentTypeData = () => {
    return [
      { name: 'Restraint Failure', value: 2 },
      { name: 'Trailer Movement', value: 1 },
      { name: 'Equipment Damage', value: 3 },
      { name: 'Slip/Fall', value: 2 },
    ];
  };

  const COLORS = ['#0F3460', '#FFCC00', '#E02401', '#00A86B'];

  // Loading state
  const isLoading = isLoadingMetrics || isLoadingLogs || isLoadingIncidents;
  if (isLoading) {
    return (
      <MainLayout title="Safety Reports" description="View safety metrics and reports">
        <div className="flex items-center justify-center h-64">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-safety-blue"></div>
        </div>
      </MainLayout>
    );
  }

  return (
    <MainLayout title="Safety Reports" description="View safety metrics and reports">
      <div className="mb-6 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <h3 className="font-heading text-xl font-bold flex items-center">
          <FileBarChart className="mr-2 h-5 w-5 text-safety-blue" />
          Safety Performance Reports
        </h3>
        
        <div className="flex items-center gap-2">
          <span className="text-sm font-medium">Timeframe:</span>
          <Select value={timeframe} onValueChange={setTimeframe}>
            <SelectTrigger className="w-[150px]">
              <SelectValue placeholder="Select period" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="week">Last Week</SelectItem>
              <SelectItem value="month">Last Month</SelectItem>
              <SelectItem value="quarter">Last Quarter</SelectItem>
              <SelectItem value="year">Last Year</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      <Tabs defaultValue="metrics" value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="grid w-full grid-cols-3 mb-6">
          <TabsTrigger value="metrics">
            <TrendingUp className="h-4 w-4 mr-2" />
            Safety Metrics
          </TabsTrigger>
          <TabsTrigger value="activity">
            <History className="h-4 w-4 mr-2" />
            Activity Log
          </TabsTrigger>
          <TabsTrigger value="checklist">
            <ClipboardList className="h-4 w-4 mr-2" />
            Checklist Performance
          </TabsTrigger>
        </TabsList>

        <TabsContent value="metrics">
          {/* Performance Overview Card */}
          <Card className="mb-6">
            <CardHeader>
              <CardTitle className="text-lg">Performance Overview</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                {/* Days Without Incidents */}
                <div className="text-center p-4 border border-gray-200 rounded-lg">
                  <div className="flex justify-center mb-2">
                    <Calendar className="h-8 w-8 text-safety-blue" />
                  </div>
                  <p className="text-gray-600 text-sm font-medium">Days Without Incidents</p>
                  <p className="text-4xl font-bold text-safety-blue mt-2">
                    {safetyMetrics?.daysSinceLastIncident || 23}
                  </p>
                  <p className="text-xs text-gray-500 mt-1">
                    Previous record: {safetyMetrics?.previousRecord || 45} days
                  </p>
                </div>

                {/* Safety Score */}
                <div className="text-center p-4 border border-gray-200 rounded-lg">
                  <div className="flex justify-center mb-2">
                    <CheckCircle className="h-8 w-8 text-safety-green" />
                  </div>
                  <p className="text-gray-600 text-sm font-medium">Monthly Safety Score</p>
                  <p className="text-4xl font-bold text-safety-green mt-2">
                    {safetyMetrics?.safetyScore || 92}%
                  </p>
                  <div className="mt-2">
                    <Progress 
                      value={safetyMetrics?.safetyScore || 92} 
                      className="h-2 bg-gray-200" 
                    />
                  </div>
                  <p className="text-xs text-gray-500 mt-1">Target: 95%</p>
                </div>

                {/* Checklist Completion */}
                <div className="text-center p-4 border border-gray-200 rounded-lg">
                  <div className="flex justify-center mb-2">
                    <ClipboardList className="h-8 w-8 text-safety-amber" />
                  </div>
                  <p className="text-gray-600 text-sm font-medium">Checklist Completion</p>
                  <p className="text-4xl font-bold text-safety-amber mt-2">
                    {safetyMetrics?.checklistCompletionRate || 87}%
                  </p>
                  <div className="mt-2">
                    <Progress 
                      value={safetyMetrics?.checklistCompletionRate || 87} 
                      className="h-2 bg-gray-200" 
                    />
                  </div>
                  <p className="text-xs text-gray-500 mt-1">Target: 100%</p>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Charts Row */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
            {/* Performance Trend Chart */}
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Performance Trend</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="h-80">
                  <ResponsiveContainer width="100%" height="100%">
                    <LineChart
                      data={getPerformanceData()}
                      margin={{
                        top: 5,
                        right: 30,
                        left: 20,
                        bottom: 5,
                      }}
                    >
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="name" />
                      <YAxis />
                      <Tooltip />
                      <Legend />
                      <Line
                        type="monotone"
                        dataKey="safetyScore"
                        stroke="#0F3460"
                        activeDot={{ r: 8 }}
                        name="Safety Score"
                      />
                      <Line 
                        type="monotone" 
                        dataKey="completionRate" 
                        stroke="#FFCC00" 
                        name="Completion Rate" 
                      />
                    </LineChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>

            {/* Incident Types Chart */}
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Incident Types</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="h-80">
                  <ResponsiveContainer width="100%" height="100%">
                    <PieChart>
                      <Pie
                        data={getIncidentTypeData()}
                        cx="50%"
                        cy="50%"
                        labelLine={false}
                        outerRadius={80}
                        fill="#8884d8"
                        dataKey="value"
                        label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
                      >
                        {getIncidentTypeData().map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                        ))}
                      </Pie>
                      <Tooltip />
                      <Legend />
                    </PieChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Incident Severity Chart */}
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Incident Severity Distribution</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="h-80">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart
                    data={[
                      { name: 'Critical', count: 1 },
                      { name: 'High', count: 2 },
                      { name: 'Medium', count: 4 },
                      { name: 'Low', count: 3 },
                    ]}
                    margin={{
                      top: 5,
                      right: 30,
                      left: 20,
                      bottom: 5,
                    }}
                  >
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="name" />
                    <YAxis />
                    <Tooltip />
                    <Bar dataKey="count" name="Incidents">
                      <Cell fill="#E02401" />
                      <Cell fill="#FFA500" />
                      <Cell fill="#FFCC00" />
                      <Cell fill="#00A86B" />
                    </Bar>
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="activity">
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Complete Activity Log</CardTitle>
            </CardHeader>
            <CardContent>
              {activityLogs.length === 0 ? (
                <div className="text-center py-8 text-gray-500">
                  No activity logs found
                </div>
              ) : (
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Date & Time</TableHead>
                      <TableHead>Type</TableHead>
                      <TableHead>Location</TableHead>
                      <TableHead>Message</TableHead>
                      <TableHead>User</TableHead>
                      <TableHead>Severity</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {activityLogs.map((log: any) => {
                      const getIcon = () => {
                        switch (log.severity) {
                          case 'error': return <AlertCircle className="h-4 w-4 text-safety-red" />;
                          case 'warning': return <AlertTriangle className="h-4 w-4 text-safety-amber" />;
                          case 'info': return <CheckCircle className="h-4 w-4 text-safety-green" />;
                          default: return <CheckCircle className="h-4 w-4 text-safety-green" />;
                        }
                      };

                      return (
                        <TableRow key={log.id}>
                          <TableCell>{new Date(log.timestamp).toLocaleString()}</TableCell>
                          <TableCell>{log.type.replace('_', ' ')}</TableCell>
                          <TableCell>Dock {log.dockId || 'N/A'}</TableCell>
                          <TableCell>{log.message}</TableCell>
                          <TableCell>J. Martinez</TableCell>
                          <TableCell>
                            <div className="flex items-center">
                              {getIcon()}
                              <span className="ml-1 capitalize">{log.severity}</span>
                            </div>
                          </TableCell>
                        </TableRow>
                      );
                    })}
                  </TableBody>
                </Table>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="checklist">
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Checklist Completion Analytics</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
                <div>
                  <h4 className="font-medium mb-4">Most Failed Checklist Items</h4>
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Item</TableHead>
                        <TableHead>Failure Rate</TableHead>
                        <TableHead>Critical</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      <TableRow>
                        <TableCell>Warning lights functioning</TableCell>
                        <TableCell>15%</TableCell>
                        <TableCell>No</TableCell>
                      </TableRow>
                      <TableRow>
                        <TableCell>Wheel chocks properly placed</TableCell>
                        <TableCell>8%</TableCell>
                        <TableCell className="text-safety-red">Yes</TableCell>
                      </TableRow>
                      <TableRow>
                        <TableCell>Trailer door fully open & secured</TableCell>
                        <TableCell>6%</TableCell>
                        <TableCell>No</TableCell>
                      </TableRow>
                    </TableBody>
                  </Table>
                </div>

                <div>
                  <h4 className="font-medium mb-4">Dock Completion Rates</h4>
                  <div className="space-y-6">
                    <div>
                      <div className="flex justify-between mb-1">
                        <span className="text-sm">Dock 1</span>
                        <span className="text-sm font-medium">95%</span>
                      </div>
                      <Progress value={95} className="h-2" />
                    </div>
                    <div>
                      <div className="flex justify-between mb-1">
                        <span className="text-sm">Dock 2</span>
                        <span className="text-sm font-medium">87%</span>
                      </div>
                      <Progress value={87} className="h-2" />
                    </div>
                    <div>
                      <div className="flex justify-between mb-1">
                        <span className="text-sm">Dock 3</span>
                        <span className="text-sm font-medium">73%</span>
                      </div>
                      <Progress value={73} className="h-2" />
                    </div>
                    <div>
                      <div className="flex justify-between mb-1">
                        <span className="text-sm">Dock 4</span>
                        <span className="text-sm font-medium">92%</span>
                      </div>
                      <Progress value={92} className="h-2" />
                    </div>
                  </div>
                </div>
              </div>

              <div className="mt-8">
                <h4 className="font-medium mb-4">Daily Checklist Completion</h4>
                <div className="h-80">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart
                      data={[
                        { date: 'Mon', completed: 12, target: 15 },
                        { date: 'Tue', completed: 15, target: 15 },
                        { date: 'Wed', completed: 13, target: 15 },
                        { date: 'Thu', completed: 14, target: 15 },
                        { date: 'Fri', completed: 11, target: 15 },
                        { date: 'Sat', completed: 8, target: 10 },
                        { date: 'Sun', completed: 7, target: 10 },
                      ]}
                      margin={{
                        top: 5,
                        right: 30,
                        left: 20,
                        bottom: 5,
                      }}
                    >
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="date" />
                      <YAxis />
                      <Tooltip />
                      <Legend />
                      <Bar dataKey="completed" name="Completed" fill="#0F3460" />
                      <Bar dataKey="target" name="Target" fill="#FFCC00" />
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      <div className="mt-6">
        <Button variant="outline" className="w-full">
          <CalendarIcon className="mr-2 h-4 w-4" />
          Export Reports
        </Button>
      </div>
    </MainLayout>
  );
};

export default Reports;
