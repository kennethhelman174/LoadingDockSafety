import React, { useState } from 'react';
import { useQuery, useMutation } from '@tanstack/react-query';
import MainLayout from '@/components/layout/MainLayout';
import { Card, CardHeader, CardTitle, CardContent, CardFooter } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { useToast } from '@/hooks/use-toast';
import { Badge } from '@/components/ui/badge';
import { apiRequest, queryClient } from '@/lib/queryClient';
import { Wrench, Activity, AlertTriangle, CheckCircle2 } from 'lucide-react';
import { Tabs, TabsList, TabsTrigger, TabsContent } from '@/components/ui/tabs';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';

// Types for maintenance data
interface MaintenanceRecord {
  id: number;
  dockId: number;
  dockName: string;
  issue: string;
  action: string;
  notes: string;
  status: 'open' | 'in_progress' | 'resolved';
  createdAt: string;
  updatedAt: string;
  technicianId: number;
  technicianName: string;
}

interface DockData {
  id: number;
  name: string;
  status: string;
}

const Maintenance: React.FC = () => {
  const { toast } = useToast();
  const [activeTab, setActiveTab] = useState('active');
  const [formVisible, setFormVisible] = useState(false);
  const [formData, setFormData] = useState({
    dockId: '',
    issue: '',
    action: '',
    notes: '',
    status: 'open',
  });
  
  // Fetch docks
  const { data: docks = [] } = useQuery({
    queryKey: ['/api/docks'],
    queryFn: async () => {
      const data = await apiRequest('GET', '/api/docks', null);
      return data || [];
    },
  });
  
  // Fetch maintenance records - this would be a real endpoint in a complete implementation
  const { data: maintenanceRecords = [], isLoading } = useQuery({
    queryKey: ['/api/maintenance'],
    queryFn: async () => {
      try {
        // Mock data for demonstration
        return [
          {
            id: 1,
            dockId: 5,
            dockName: 'Dock 100',
            issue: 'Dock leveler not retracting fully',
            action: 'Replacing hydraulic cylinder',
            notes: 'Parts ordered, scheduled for repair on 5/20',
            status: 'in_progress',
            createdAt: '2025-05-15T10:30:00Z',
            updatedAt: '2025-05-16T14:45:00Z',
            technicianId: 2,
            technicianName: 'Alex Rodriguez'
          },
          {
            id: 2,
            dockId: 8,
            dockName: 'Dock 103',
            issue: 'Vehicle restraint sensor failure',
            action: 'Replace proximity sensor',
            notes: 'Emergency repair needed',
            status: 'open',
            createdAt: '2025-05-17T08:15:00Z',
            updatedAt: '2025-05-17T08:15:00Z',
            technicianId: 1,
            technicianName: 'Maria Johnson'
          },
          {
            id: 3,
            dockId: 12,
            dockName: 'Dock 107',
            issue: 'Door seal damaged',
            action: 'Replaced weather seal',
            notes: 'Completed ahead of schedule',
            status: 'resolved',
            createdAt: '2025-05-10T13:20:00Z',
            updatedAt: '2025-05-12T11:30:00Z',
            technicianId: 3,
            technicianName: 'Carlos Smith'
          }
        ];
      } catch (error) {
        console.error('Error fetching maintenance records:', error);
        return [];
      }
    }
  });

  // Handle form input changes
  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  // Handle select changes
  const handleSelectChange = (name: string, value: string) => {
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  // Create new maintenance record
  const createMaintenance = useMutation({
    mutationFn: async (data: typeof formData) => {
      // In a real app, this would submit to the API
      console.log('Creating maintenance record:', data);
      // Mock successful submission
      return { success: true };
    },
    onSuccess: () => {
      // In a real app, invalidate the query to refresh data
      queryClient.invalidateQueries({ queryKey: ['/api/maintenance'] });
      
      toast({
        title: "Maintenance Record Created",
        description: "The maintenance record has been created successfully",
      });
      
      // Reset form
      setFormData({
        dockId: '',
        issue: '',
        action: '',
        notes: '',
        status: 'open',
      });
      setFormVisible(false);
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to create maintenance record",
        variant: "destructive"
      });
    }
  });

  // Update maintenance record status
  const updateMaintenanceStatus = useMutation({
    mutationFn: async ({ id, status }: { id: number, status: string }) => {
      // In a real app, this would update via the API
      console.log(`Updating maintenance record ${id} to status: ${status}`);
      // Mock successful update
      return { success: true };
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/maintenance'] });
      toast({
        title: "Status Updated",
        description: "Maintenance record status updated successfully",
      });
    }
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    // Validate form
    if (!formData.dockId || !formData.issue || !formData.action) {
      toast({
        title: "Missing Information",
        description: "Please fill out all required fields",
        variant: "destructive"
      });
      return;
    }
    
    // Submit form
    createMaintenance.mutate(formData);
  };

  const handleStatusChange = (id: number, newStatus: 'open' | 'in_progress' | 'resolved') => {
    updateMaintenanceStatus.mutate({ id, status: newStatus });
  };

  // Filter records based on active tab
  const filteredRecords = maintenanceRecords.filter((record: MaintenanceRecord) => {
    if (activeTab === 'active') return record.status !== 'resolved';
    if (activeTab === 'open') return record.status === 'open';
    if (activeTab === 'in_progress') return record.status === 'in_progress';
    if (activeTab === 'resolved') return record.status === 'resolved';
    return true;
  });

  // Render status badge with appropriate color
  const renderStatusBadge = (status: string) => {
    switch (status) {
      case 'open':
        return <Badge variant="warning">Open</Badge>;
      case 'in_progress':
        return <Badge variant="secondary">In Progress</Badge>;
      case 'resolved':
        return <Badge variant="success">Resolved</Badge>;
      default:
        return <Badge>{status}</Badge>;
    }
  };

  return (
    <MainLayout title="Maintenance Management" description="Track and manage dock maintenance">
      <div className="mb-6 flex flex-wrap justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold flex items-center">
            <Wrench className="mr-3 h-8 w-8 text-primary" />
            Maintenance Management
          </h1>
          <p className="text-gray-600 dark:text-gray-400 mt-2">
            Track maintenance issues and repairs for all loading docks
          </p>
        </div>
        
        <Button 
          onClick={() => setFormVisible(!formVisible)}
          className="mt-4 sm:mt-0"
        >
          {formVisible ? 'Cancel' : 'Create Maintenance Record'}
        </Button>
      </div>
      
      {/* New Maintenance Form */}
      {formVisible && (
        <Card className="mb-6">
          <CardHeader>
            <CardTitle>New Maintenance Record</CardTitle>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="dockId">Dock *</Label>
                  <Select 
                    onValueChange={(value) => handleSelectChange('dockId', value)}
                    value={formData.dockId}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Select a dock" />
                    </SelectTrigger>
                    <SelectContent>
                      {docks.map((dock: DockData) => (
                        <SelectItem key={dock.id} value={dock.id.toString()}>
                          {dock.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="status">Status *</Label>
                  <Select 
                    onValueChange={(value) => handleSelectChange('status', value)}
                    value={formData.status}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Select status" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="open">Open</SelectItem>
                      <SelectItem value="in_progress">In Progress</SelectItem>
                      <SelectItem value="resolved">Resolved</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="issue">Issue Description *</Label>
                <Textarea
                  id="issue"
                  name="issue"
                  placeholder="Describe the maintenance issue"
                  value={formData.issue}
                  onChange={handleInputChange}
                  rows={3}
                />
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="action">Corrective Action *</Label>
                <Textarea
                  id="action"
                  name="action"
                  placeholder="Describe the corrective action needed"
                  value={formData.action}
                  onChange={handleInputChange}
                  rows={3}
                />
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="notes">Additional Notes</Label>
                <Textarea
                  id="notes"
                  name="notes"
                  placeholder="Any additional notes or details"
                  value={formData.notes}
                  onChange={handleInputChange}
                  rows={2}
                />
              </div>
            </form>
          </CardContent>
          <CardFooter className="flex justify-end">
            <Button onClick={() => setFormVisible(false)} variant="outline" className="mr-2">
              Cancel
            </Button>
            <Button onClick={handleSubmit}>
              Create Record
            </Button>
          </CardFooter>
        </Card>
      )}
      
      {/* Maintenance Records */}
      <Card>
        <CardHeader>
          <CardTitle>Maintenance Records</CardTitle>
        </CardHeader>
        <CardContent>
          <Tabs defaultValue="active" onValueChange={setActiveTab}>
            <TabsList className="mb-4">
              <TabsTrigger value="active">Active</TabsTrigger>
              <TabsTrigger value="open">Open</TabsTrigger>
              <TabsTrigger value="in_progress">In Progress</TabsTrigger>
              <TabsTrigger value="resolved">Resolved</TabsTrigger>
              <TabsTrigger value="all">All</TabsTrigger>
            </TabsList>
            
            <div className="rounded-md border">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Dock</TableHead>
                    <TableHead>Issue</TableHead>
                    <TableHead>Corrective Action</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Date</TableHead>
                    <TableHead>Technician</TableHead>
                    <TableHead>Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredRecords.length > 0 ? (
                    filteredRecords.map((record: MaintenanceRecord) => (
                      <TableRow key={record.id}>
                        <TableCell>{record.dockName}</TableCell>
                        <TableCell>
                          <div className="font-medium">{record.issue}</div>
                          {record.notes && (
                            <div className="text-xs text-gray-500 mt-1">{record.notes}</div>
                          )}
                        </TableCell>
                        <TableCell>{record.action}</TableCell>
                        <TableCell>{renderStatusBadge(record.status)}</TableCell>
                        <TableCell>{new Date(record.createdAt).toLocaleDateString()}</TableCell>
                        <TableCell>{record.technicianName}</TableCell>
                        <TableCell>
                          <div className="flex space-x-1">
                            {record.status === 'open' && (
                              <Button 
                                variant="ghost" 
                                size="sm" 
                                onClick={() => handleStatusChange(record.id, 'in_progress')}
                                className="text-xs flex items-center"
                              >
                                <Activity className="h-3 w-3 mr-1" />
                                Start
                              </Button>
                            )}
                            {record.status === 'in_progress' && (
                              <Button 
                                variant="ghost" 
                                size="sm" 
                                onClick={() => handleStatusChange(record.id, 'resolved')}
                                className="text-xs flex items-center"
                              >
                                <CheckCircle2 className="h-3 w-3 mr-1" />
                                Complete
                              </Button>
                            )}
                            {record.status === 'resolved' && (
                              <Button 
                                variant="ghost" 
                                size="sm" 
                                onClick={() => handleStatusChange(record.id, 'open')}
                                className="text-xs flex items-center"
                              >
                                <AlertTriangle className="h-3 w-3 mr-1" />
                                Reopen
                              </Button>
                            )}
                          </div>
                        </TableCell>
                      </TableRow>
                    ))
                  ) : (
                    <TableRow>
                      <TableCell colSpan={7} className="text-center py-6 text-gray-500">
                        No maintenance records found for the selected filter
                      </TableCell>
                    </TableRow>
                  )}
                </TableBody>
              </Table>
            </div>
          </Tabs>
        </CardContent>
      </Card>
    </MainLayout>
  );
};

export default Maintenance;