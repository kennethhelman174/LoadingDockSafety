import React, { useState } from 'react';
import { useQuery, useMutation } from '@tanstack/react-query';
import { useLocation } from 'wouter';
import MainLayout from '@/components/layout/MainLayout';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { Plus, Truck, LogOut } from 'lucide-react';
import { queryClient, apiRequest } from '@/lib/queryClient';
import { useToast } from '@/hooks/use-toast';

const Vehicles: React.FC = () => {
  const [, navigate] = useLocation();
  const { toast } = useToast();
  const [processingExit, setProcessingExit] = useState<number | null>(null);

  // Fetch vehicles
  const { data: vehicles = [], isLoading } = useQuery({
    queryKey: ['/api/vehicles'],
  });

  // Fetch docks for reference
  const { data: docks = [] } = useQuery({
    queryKey: ['/api/docks'],
  });

  // Mark vehicle exit mutation
  const exitMutation = useMutation({
    mutationFn: async (vehicleId: number) => {
      setProcessingExit(vehicleId);
      await apiRequest('PUT', `/api/vehicles/${vehicleId}/exit`, { userId: 1 });
      setProcessingExit(null);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/vehicles'] });
      toast({
        title: 'Vehicle Exited',
        description: 'Vehicle has been marked as exited and dock is available',
      });
    },
    onError: () => {
      setProcessingExit(null);
      toast({
        title: 'Operation Failed',
        description: 'Failed to process vehicle exit',
        variant: 'destructive',
      });
    },
  });

  const handleVehicleExit = (vehicleId: number) => {
    exitMutation.mutate(vehicleId);
  };

  const getDockName = (dockId: number | null) => {
    if (!dockId) return 'Not Assigned';
    const dock = docks.find((d: any) => d.id === dockId);
    return dock ? dock.name : 'Unknown';
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'loading':
        return <Badge className="bg-safety-blue">Loading</Badge>;
      case 'unloading':
        return <Badge className="bg-safety-amber">Unloading</Badge>;
      case 'pending':
        return <Badge className="bg-gray-500">Pending</Badge>;
      case 'complete':
        return <Badge className="bg-safety-green">Complete</Badge>;
      default:
        return <Badge>{status}</Badge>;
    }
  };

  const activeVehicles = vehicles.filter((v: any) => !v.exitTime);
  const completedVehicles = vehicles.filter((v: any) => v.exitTime);

  if (isLoading) {
    return (
      <MainLayout title="Vehicle Tracking" description="Monitor and manage vehicles at loading docks">
        <div className="flex items-center justify-center h-64">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-safety-blue"></div>
        </div>
      </MainLayout>
    );
  }

  return (
    <MainLayout title="Vehicle Tracking" description="Monitor and manage vehicles at loading docks">
      <div className="flex justify-between items-center mb-6">
        <h3 className="text-xl font-bold flex items-center">
          <Truck className="mr-2 h-5 w-5 text-safety-blue" />
          Vehicle Management
        </h3>
        <Button
          className="bg-safety-blue hover:bg-blue-700"
          onClick={() => navigate('/vehicles/new')}
        >
          <Plus className="mr-2 h-4 w-4" /> Add New Vehicle
        </Button>
      </div>

      <Card className="mb-6">
        <CardHeader>
          <CardTitle>Active Vehicles</CardTitle>
        </CardHeader>
        <CardContent>
          {activeVehicles.length === 0 ? (
            <div className="text-center py-8 text-gray-500">
              No active vehicles currently at facility
            </div>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Trailer Number</TableHead>
                  <TableHead>Driver</TableHead>
                  <TableHead>Company</TableHead>
                  <TableHead>Assigned Dock</TableHead>
                  <TableHead>Entry Time</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead className="text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {activeVehicles.map((vehicle: any) => (
                  <TableRow key={vehicle.id}>
                    <TableCell className="font-semibold">{vehicle.trailerNumber}</TableCell>
                    <TableCell>{vehicle.driverName || 'N/A'}</TableCell>
                    <TableCell>{vehicle.company || 'N/A'}</TableCell>
                    <TableCell>{getDockName(vehicle.dockId)}</TableCell>
                    <TableCell>{new Date(vehicle.entryTime).toLocaleString()}</TableCell>
                    <TableCell>{getStatusBadge(vehicle.status)}</TableCell>
                    <TableCell className="text-right">
                      <Button
                        variant="outline"
                        size="sm"
                        className="text-safety-red border-safety-red hover:bg-red-50"
                        onClick={() => handleVehicleExit(vehicle.id)}
                        disabled={processingExit === vehicle.id}
                      >
                        {processingExit === vehicle.id ? (
                          <span className="animate-spin h-4 w-4 border-b-2 border-safety-red rounded-full mr-2" />
                        ) : (
                          <LogOut className="mr-2 h-4 w-4" />
                        )}
                        Mark Exit
                      </Button>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Vehicle History</CardTitle>
        </CardHeader>
        <CardContent>
          {completedVehicles.length === 0 ? (
            <div className="text-center py-8 text-gray-500">
              No vehicle history available
            </div>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Trailer Number</TableHead>
                  <TableHead>Driver</TableHead>
                  <TableHead>Company</TableHead>
                  <TableHead>Entry Time</TableHead>
                  <TableHead>Exit Time</TableHead>
                  <TableHead>Duration</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {completedVehicles.map((vehicle: any) => {
                  const entryTime = new Date(vehicle.entryTime);
                  const exitTime = new Date(vehicle.exitTime);
                  const durationMs = exitTime.getTime() - entryTime.getTime();
                  const hours = Math.floor(durationMs / (1000 * 60 * 60));
                  const minutes = Math.floor((durationMs % (1000 * 60 * 60)) / (1000 * 60));
                  
                  return (
                    <TableRow key={vehicle.id}>
                      <TableCell>{vehicle.trailerNumber}</TableCell>
                      <TableCell>{vehicle.driverName || 'N/A'}</TableCell>
                      <TableCell>{vehicle.company || 'N/A'}</TableCell>
                      <TableCell>{entryTime.toLocaleString()}</TableCell>
                      <TableCell>{exitTime.toLocaleString()}</TableCell>
                      <TableCell>{`${hours}h ${minutes}m`}</TableCell>
                    </TableRow>
                  );
                })}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>
    </MainLayout>
  );
};

export default Vehicles;
