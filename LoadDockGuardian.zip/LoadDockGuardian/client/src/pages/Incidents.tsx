import React, { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { useLocation } from 'wouter';
import MainLayout from '@/components/layout/MainLayout';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { AlertTriangle, Plus, Eye, CheckCircle2 } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

const Incidents: React.FC = () => {
  const [, navigate] = useLocation();
  const { toast } = useToast();
  const [activeTab, setActiveTab] = useState('open');

  // Fetch incidents
  const { data: incidents = [], isLoading } = useQuery({
    queryKey: ['/api/incidents'],
  });

  // Fetch docks for reference
  const { data: docks = [] } = useQuery({
    queryKey: ['/api/docks'],
  });

  const getDockName = (dockId: number) => {
    const dock = docks.find((d: any) => d.id === dockId);
    return dock ? dock.name : 'Unknown';
  };

  const getSeverityBadge = (severity: string) => {
    switch (severity) {
      case 'critical':
        return <Badge className="bg-safety-red">Critical</Badge>;
      case 'high':
        return <Badge className="bg-safety-amber">High</Badge>;
      case 'medium':
        return <Badge className="bg-gray-500">Medium</Badge>;
      case 'low':
        return <Badge className="bg-gray-400">Low</Badge>;
      default:
        return <Badge>{severity}</Badge>;
    }
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'open':
        return <Badge className="bg-safety-red">Open</Badge>;
      case 'in_progress':
        return <Badge className="bg-safety-amber">In Progress</Badge>;
      case 'resolved':
        return <Badge className="bg-safety-green">Resolved</Badge>;
      default:
        return <Badge>{status}</Badge>;
    }
  };

  const openIncidents = incidents.filter((incident: any) => incident.status !== 'resolved');
  const resolvedIncidents = incidents.filter((incident: any) => incident.status === 'resolved');

  if (isLoading) {
    return (
      <MainLayout title="Incident Reports" description="View and report safety incidents">
        <div className="flex items-center justify-center h-64">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-safety-blue"></div>
        </div>
      </MainLayout>
    );
  }

  return (
    <MainLayout title="Incident Reports" description="View and report safety incidents">
      <div className="flex justify-between items-center mb-6">
        <h3 className="text-xl font-bold flex items-center">
          <AlertTriangle className="mr-2 h-5 w-5 text-safety-red" />
          Incident Management
        </h3>
        <Button
          className="bg-safety-blue hover:bg-blue-700"
          onClick={() => navigate('/incidents/new')}
        >
          <Plus className="mr-2 h-4 w-4" /> Report New Incident
        </Button>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>All Incidents</CardTitle>
        </CardHeader>
        <CardContent>
          <Tabs defaultValue="open" value={activeTab} onValueChange={setActiveTab}>
            <TabsList className="grid w-full grid-cols-2 mb-6">
              <TabsTrigger value="open" className="relative">
                Open Incidents
                {openIncidents.length > 0 && (
                  <span className="absolute top-0 right-1 transform -translate-y-1/2 bg-safety-red text-white rounded-full w-5 h-5 flex items-center justify-center text-xs">
                    {openIncidents.length}
                  </span>
                )}
              </TabsTrigger>
              <TabsTrigger value="resolved">Resolved</TabsTrigger>
            </TabsList>

            <TabsContent value="open">
              {openIncidents.length === 0 ? (
                <div className="text-center py-8 text-gray-500">
                  No open incidents found. Safety first!
                </div>
              ) : (
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Date</TableHead>
                      <TableHead>Title</TableHead>
                      <TableHead>Location</TableHead>
                      <TableHead>Severity</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead className="text-right">Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {openIncidents.map((incident: any) => (
                      <TableRow key={incident.id}>
                        <TableCell>
                          {new Date(incident.reportedAt).toLocaleDateString()}
                        </TableCell>
                        <TableCell className="font-medium">{incident.title}</TableCell>
                        <TableCell>{getDockName(incident.dockId)}</TableCell>
                        <TableCell>{getSeverityBadge(incident.severity)}</TableCell>
                        <TableCell>{getStatusBadge(incident.status)}</TableCell>
                        <TableCell className="text-right">
                          <div className="flex justify-end gap-2">
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={() => {
                                toast({
                                  title: "Viewing Incident",
                                  description: incident.title,
                                });
                              }}
                            >
                              <Eye className="h-4 w-4" />
                            </Button>
                            <Button
                              variant="outline"
                              size="sm"
                              className="text-safety-green border-safety-green hover:bg-green-50"
                              onClick={() => {
                                toast({
                                  title: "Resolving Incident",
                                  description: "This feature will be available soon",
                                });
                              }}
                            >
                              <CheckCircle2 className="h-4 w-4" />
                            </Button>
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              )}
            </TabsContent>

            <TabsContent value="resolved">
              {resolvedIncidents.length === 0 ? (
                <div className="text-center py-8 text-gray-500">
                  No resolved incidents found.
                </div>
              ) : (
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Date</TableHead>
                      <TableHead>Title</TableHead>
                      <TableHead>Location</TableHead>
                      <TableHead>Severity</TableHead>
                      <TableHead>Resolved Date</TableHead>
                      <TableHead className="text-right">Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {resolvedIncidents.map((incident: any) => (
                      <TableRow key={incident.id}>
                        <TableCell>
                          {new Date(incident.reportedAt).toLocaleDateString()}
                        </TableCell>
                        <TableCell className="font-medium">{incident.title}</TableCell>
                        <TableCell>{getDockName(incident.dockId)}</TableCell>
                        <TableCell>{getSeverityBadge(incident.severity)}</TableCell>
                        <TableCell>
                          {incident.resolvedAt
                            ? new Date(incident.resolvedAt).toLocaleDateString()
                            : 'N/A'}
                        </TableCell>
                        <TableCell className="text-right">
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => {
                              toast({
                                title: "Viewing Incident",
                                description: incident.title,
                              });
                            }}
                          >
                            <Eye className="h-4 w-4" />
                          </Button>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              )}
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>
    </MainLayout>
  );
};

export default Incidents;
