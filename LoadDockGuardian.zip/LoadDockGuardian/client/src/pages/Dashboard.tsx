import React, { useState, useEffect } from 'react';
import { useQuery, useMutation } from '@tanstack/react-query';
import { useLocation } from 'wouter';
import MainLayout from '@/components/layout/MainLayout';
import DockStatusCard from '@/components/dashboard/DockStatusCard';
import AlertBanner from '@/components/dashboard/AlertBanner';
import SafetyChecklistWidget, { ChecklistItem } from '@/components/dashboard/SafetyChecklistWidget';
import ActivityLog, { ActivityItem } from '@/components/dashboard/ActivityLog';
import SafetyMetrics from '@/components/dashboard/SafetyMetrics';
import QuickActions from '@/components/dashboard/QuickActions';
import { apiRequest } from '@/lib/queryClient';
import { useToast } from '@/hooks/use-toast';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { Button } from '@/components/ui/button';
import { NotificationTester } from '@/components/notifications/NotificationTester';

const Dashboard: React.FC = () => {
  const [, navigate] = useLocation();
  const { toast } = useToast();
  const [showAlert, setShowAlert] = useState(true);
  const [scheduleDialogOpen, setScheduleDialogOpen] = useState(false);
  const [helpDialogOpen, setHelpDialogOpen] = useState(false);

  // Initialize demo data on first load
  const initDemoData = useMutation({
    mutationFn: async () => {
      await apiRequest('POST', '/api/init-demo-data', {});
    },
  });

  useEffect(() => {
    initDemoData.mutate();
  }, []);

  // Fetch docks data
  const { data: docks = [], isLoading: isLoadingDocks } = useQuery({
    queryKey: ['/api/docks'],
    refetchInterval: 30000, // Refresh every 30 seconds
    select: (data) => Array.isArray(data) ? data : []
  });

  // Fetch checklist items
  const { data: checklistItems = [], isLoading: isLoadingChecklist } = useQuery({
    queryKey: ['/api/checklist-items'],
    select: (data) => Array.isArray(data) ? data : []
  });

  // Fetch recent activity
  const { data: activityLogs = [], isLoading: isLoadingActivity } = useQuery({
    queryKey: ['/api/activity-log'],
    select: (data) => Array.isArray(data) ? data : []
  });

  // Fetch safety metrics
  const { data: metrics = {
    daysSinceLastIncident: 23,
    safetyScore: 92,
    checklistCompletionRate: 87,
    previousRecord: 45
  }, isLoading: isLoadingMetrics } = useQuery({
    queryKey: ['/api/safety-metrics'],
  });
  
  // Safety metrics for use in the component
  const safetyMetrics = {
    daysSinceLastIncident: 23,
    safetyScore: 92,
    checklistCompletionRate: 87,
    previousRecord: 45
  };

  // Prepare checklist items for the widget
  const preparedChecklistItems: ChecklistItem[] = (checklistItems || []).map((item: any) => ({
    id: item.id,
    text: item.text,
    description: item.description,
    isCritical: item.isCritical,
    checked: false
  }));

  // Map activity logs to ActivityItem format
  const mapActivityLogToItems = (logs: any[]): ActivityItem[] => {
    if (!logs || !Array.isArray(logs)) return [];
    return logs.map(log => {
      const type = log.severity === 'error' ? 'error' : 
                  log.severity === 'warning' ? 'warning' :
                  log.type === 'safety_check' && log.message && log.message.includes('Completed') ? 'success' : 'info';
      
      return {
        id: log.id,
        type,
        title: log.message || 'Activity logged',
        description: `Verified by ${log.userId === 1 ? 'J. Martinez' : 'System'}`,
        time: log.timestamp ? new Date(log.timestamp).toLocaleString() : new Date().toLocaleString(),
      };
    });
  };

  // Convert dock status to card status
  const mapDockStatusToCardStatus = (status: string) => {
    switch (status) {
      case 'in_use': return 'safe';
      case 'caution': return 'caution';
      case 'danger': return 'danger';
      case 'available': return 'available';
      default: return 'available';
    }
  };

  // Handle checklist submission
  const handleChecklistSubmit = async (items: ChecklistItem[]) => {
    try {
      const allPassed = items.every(item => item.checked);
      
      await apiRequest('POST', '/api/completed-checklists', {
        dockId: 1, // Default to Dock 1 for the dashboard widget
        userId: 1,
        results: items,
        allPassed
      });

      toast({
        title: "Checklist Completed",
        description: "Safety checklist has been recorded successfully",
      });
    } catch (error) {
      toast({
        title: "Submission Failed",
        description: "There was an error submitting the checklist",
        variant: "destructive"
      });
    }
  };

  // Render loading state
  if (isLoadingDocks || isLoadingChecklist || isLoadingActivity || isLoadingMetrics) {
    return (
      <MainLayout title="Loading Dock Dashboard" description="Safety status and operational overview">
        <div className="flex items-center justify-center h-64">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-safety-blue"></div>
        </div>
      </MainLayout>
    );
  }

  return (
    <MainLayout title="Loading Dock Dashboard" description="Safety status and operational overview">
      {/* Alert Banner (if active) */}
      {showAlert && (
        <AlertBanner
          title="SAFETY ALERT"
          message="Dock 3 restraint failure detected. Maintenance has been notified. Do not use until resolved."
          onClose={() => setShowAlert(false)}
        />
      )}
      
      {/* Safety Status Overview with Tabs */}
      <div className="mb-8">
        <h3 className="text-xl font-bold mb-4">Dock Status Overview</h3>
        
        <div className="mb-4">
          <Tabs defaultValue="shipping">
            <TabsList className="w-full">
              <TabsTrigger className="flex-1" value="shipping">Shipping (100-112)</TabsTrigger>
              <TabsTrigger className="flex-1" value="export-shipping">Export Shipping (113-129)</TabsTrigger>
              <TabsTrigger className="flex-1" value="receiving">Receiving (200-212)</TabsTrigger>
              <TabsTrigger className="flex-1" value="export-receiving">Export Receiving (213-222)</TabsTrigger>
            </TabsList>
            
            {/* Shipping Docks (100-112) */}
            <TabsContent value="shipping">
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                {(docks || [])
                  .filter((dock: any) => {
                    const dockNumber = parseInt(dock.name.replace(/\D/g, ''));
                    return dockNumber >= 100 && dockNumber <= 112;
                  })
                  .map((dock: any) => (
                    <DockStatusCard
                      key={dock.id}
                      id={dock.id}
                      name={dock.name}
                      status={mapDockStatusToCardStatus(dock.status)}
                      timeInfo={dock.status === 'available' ? "Last active: 06:15 AM" : "Active since: 08:45 AM"}
                      trailerInfo={dock.status !== 'available' && dock.status !== 'danger' ? "Trailer #TRL-45672" : undefined}
                      checkItems={[
                        { 
                          text: "Wheel chocks in place", 
                          status: dock.status === 'available' ? 'neutral' : 'success' 
                        },
                        { 
                          text: dock.status === 'danger' ? "Restraint system offline" : "Restraint engaged", 
                          status: dock.status === 'danger' ? 'error' : dock.status === 'caution' ? 'warning' : dock.status === 'available' ? 'neutral' : 'success'
                        },
                        { 
                          text: dock.status === 'danger' ? "Signal lights inoperative" : "Signal lights active", 
                          status: dock.status === 'danger' ? 'error' : dock.status === 'available' ? 'neutral' : 'success' 
                        }
                      ]}
                      onViewDetails={() => toast({
                        title: "Details",
                        description: `Viewing details for ${dock.name}`,
                      })}
                      onManage={() => navigate(`/checklists?dock=${dock.id}`)}
                    />
                  ))}
              </div>
            </TabsContent>
            
            {/* Export Shipping Docks (113-129) */}
            <TabsContent value="export-shipping">
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                {(docks || [])
                  .filter((dock: any) => {
                    const dockNumber = parseInt(dock.name.replace(/\D/g, ''));
                    return dockNumber >= 113 && dockNumber <= 129;
                  })
                  .map((dock: any) => (
                    <DockStatusCard
                      key={dock.id}
                      id={dock.id}
                      name={dock.name}
                      status={mapDockStatusToCardStatus(dock.status)}
                      timeInfo={dock.status === 'available' ? "Last active: 06:15 AM" : "Active since: 08:45 AM"}
                      trailerInfo={dock.status !== 'available' && dock.status !== 'danger' ? "Trailer #TRL-45672" : undefined}
                      checkItems={[
                        { 
                          text: "Wheel chocks in place", 
                          status: dock.status === 'available' ? 'neutral' : 'success' 
                        },
                        { 
                          text: dock.status === 'danger' ? "Restraint system offline" : "Restraint engaged", 
                          status: dock.status === 'danger' ? 'error' : dock.status === 'caution' ? 'warning' : dock.status === 'available' ? 'neutral' : 'success'
                        },
                        { 
                          text: dock.status === 'danger' ? "Signal lights inoperative" : "Signal lights active", 
                          status: dock.status === 'danger' ? 'error' : dock.status === 'available' ? 'neutral' : 'success' 
                        }
                      ]}
                      onViewDetails={() => toast({
                        title: "Details",
                        description: `Viewing details for ${dock.name}`,
                      })}
                      onManage={() => navigate(`/checklists?dock=${dock.id}`)}
                    />
                  ))}
              </div>
            </TabsContent>
            
            {/* Receiving Docks (200-212) */}
            <TabsContent value="receiving">
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                {(docks || [])
                  .filter((dock: any) => {
                    const dockNumber = parseInt(dock.name.replace(/\D/g, ''));
                    return dockNumber >= 200 && dockNumber <= 212;
                  })
                  .map((dock: any) => (
                    <DockStatusCard
                      key={dock.id}
                      id={dock.id}
                      name={dock.name}
                      status={mapDockStatusToCardStatus(dock.status)}
                      timeInfo={dock.status === 'available' ? "Last active: 06:15 AM" : "Active since: 08:45 AM"}
                      trailerInfo={dock.status !== 'available' && dock.status !== 'danger' ? "Trailer #TRL-45672" : undefined}
                      checkItems={[
                        { 
                          text: "Wheel chocks in place", 
                          status: dock.status === 'available' ? 'neutral' : 'success' 
                        },
                        { 
                          text: dock.status === 'danger' ? "Restraint system offline" : "Restraint engaged", 
                          status: dock.status === 'danger' ? 'error' : dock.status === 'caution' ? 'warning' : dock.status === 'available' ? 'neutral' : 'success'
                        },
                        { 
                          text: dock.status === 'danger' ? "Signal lights inoperative" : "Signal lights active", 
                          status: dock.status === 'danger' ? 'error' : dock.status === 'available' ? 'neutral' : 'success' 
                        }
                      ]}
                      onViewDetails={() => toast({
                        title: "Details",
                        description: `Viewing details for ${dock.name}`,
                      })}
                      onManage={() => navigate(`/checklists?dock=${dock.id}`)}
                    />
                  ))}
              </div>
            </TabsContent>
            
            {/* Export Receiving Docks (213-222) */}
            <TabsContent value="export-receiving">
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                {(docks || [])
                  .filter((dock: any) => {
                    const dockNumber = parseInt(dock.name.replace(/\D/g, ''));
                    return dockNumber >= 213 && dockNumber <= 222;
                  })
                  .map((dock: any) => (
                    <DockStatusCard
                      key={dock.id}
                      id={dock.id}
                      name={dock.name}
                      status={mapDockStatusToCardStatus(dock.status)}
                      timeInfo={dock.status === 'available' ? "Last active: 06:15 AM" : "Active since: 08:45 AM"}
                      trailerInfo={dock.status !== 'available' && dock.status !== 'danger' ? "Trailer #TRL-45672" : undefined}
                      checkItems={[
                        { 
                          text: "Wheel chocks in place", 
                          status: dock.status === 'available' ? 'neutral' : 'success' 
                        },
                        { 
                          text: dock.status === 'danger' ? "Restraint system offline" : "Restraint engaged", 
                          status: dock.status === 'danger' ? 'error' : dock.status === 'caution' ? 'warning' : dock.status === 'available' ? 'neutral' : 'success'
                        },
                        { 
                          text: dock.status === 'danger' ? "Signal lights inoperative" : "Signal lights active", 
                          status: dock.status === 'danger' ? 'error' : dock.status === 'available' ? 'neutral' : 'success' 
                        }
                      ]}
                      onViewDetails={() => toast({
                        title: "Details",
                        description: `Viewing details for ${dock.name}`,
                      })}
                      onManage={() => navigate(`/checklists?dock=${dock.id}`)}
                    />
                  ))}
              </div>
            </TabsContent>
          </Tabs>
        </div>
      </div>
      
      {/* Safety Checklist Quick Access */}
      <div className="mb-8">
        <SafetyChecklistWidget 
          items={preparedChecklistItems} 
          onSubmit={handleChecklistSubmit}
        />
      </div>
      
      {/* Recent Activity & Metrics Row */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-8">
        {/* Recent Activity */}
        <div className="lg:col-span-2">
          <ActivityLog 
            activities={mapActivityLogToItems(activityLogs)} 
            onViewAll={() => navigate('/reports')}
          />
        </div>
        
        {/* Safety Metrics */}
        <div>
          <SafetyMetrics 
            daysSinceLastIncident={safetyMetrics.daysSinceLastIncident}
            safetyScore={safetyMetrics.safetyScore}
            checklistCompletionRate={safetyMetrics.checklistCompletionRate}
            previousRecord={safetyMetrics.previousRecord}
            onViewFullReport={() => navigate('/reports')}
          />
        </div>
      </div>
      
      {/* Quick Actions */}
      <QuickActions 
        onScheduleCheck={() => setScheduleDialogOpen(true)}
        onRequestHelp={() => setHelpDialogOpen(true)}
      />
      
      {/* Notification Testing Section (Developer Tool) */}
      <div className="mt-8 border-t pt-8">
        <h3 className="text-xl font-bold mb-4">Development Tools</h3>
        <NotificationTester />
      </div>

      {/* Schedule Check Dialog */}
      <Dialog open={scheduleDialogOpen} onOpenChange={setScheduleDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Schedule Safety Check</DialogTitle>
            <DialogDescription>
              Set up a scheduled safety inspection for dock equipment.
            </DialogDescription>
          </DialogHeader>
          <div className="py-4">
            <p className="text-sm text-muted-foreground">
              This feature allows you to schedule routine safety checks for dock equipment.
              The scheduling functionality will be available in a future update.
            </p>
          </div>
          <DialogFooter>
            <Button onClick={() => setScheduleDialogOpen(false)}>
              Close
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Request Help Dialog */}
      <Dialog open={helpDialogOpen} onOpenChange={setHelpDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Request Assistance</DialogTitle>
            <DialogDescription>
              Request immediate assistance for dock operations or safety concerns.
            </DialogDescription>
          </DialogHeader>
          <div className="py-4">
            <p className="text-sm text-muted-foreground">
              This feature allows you to request assistance from safety personnel or supervisors.
              The help request functionality will be available in a future update.
            </p>
          </div>
          <DialogFooter>
            <Button onClick={() => setHelpDialogOpen(false)}>
              Close
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </MainLayout>
  );
};

export default Dashboard;
