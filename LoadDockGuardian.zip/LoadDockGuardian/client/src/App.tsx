import { Switch, Route } from "wouter";
import MainLayout from "@/components/layout/MainLayout";
import Dashboard from "@/pages/Dashboard";
import Checklists from "@/pages/Checklists";
import Incidents from "@/pages/Incidents";
import Vehicles from "@/pages/Vehicles";
import Reports from "@/pages/Reports";
import NotFound from "@/pages/not-found";
import NewVehicle from "@/pages/NewVehicle";
import NewIncident from "@/pages/NewIncident";
import KioskMode from "@/pages/KioskMode";
import TrailerRelease from "@/pages/TrailerRelease";
import DockDetail from "@/pages/DockDetail";
import Maintenance from "@/pages/Maintenance";
import Analytics from "@/pages/Analytics";
import SystemIntegration from "@/pages/SystemIntegration";
import KioskDisplay from "@/pages/KioskDisplay";
import TrailerManagement from "@/pages/TrailerManagement";
import DockEmployeeDashboard from "@/pages/DockEmployeeDashboard";
import AdminPanel from "@/pages/AdminPanel";
import { NotificationCenter } from "@/components/notifications/NotificationCenter";
import { Toaster } from "@/components/ui/toaster";

function App() {
  return (
    <>
      {/* Global components */}
      <NotificationCenter />
      <Toaster />
      
      {/* Routes */}
      <Switch>
        <Route path="/" component={Dashboard} />
        <Route path="/checklists" component={Checklists} />
        <Route path="/incidents" component={Incidents} />
        <Route path="/vehicles" component={Vehicles} />
        <Route path="/reports" component={Reports} />
        <Route path="/vehicles/new" component={NewVehicle} />
        <Route path="/incidents/new" component={NewIncident} />
        <Route path="/kiosk" component={KioskMode} />
        <Route path="/trailer-release" component={TrailerRelease} />
        <Route path="/maintenance" component={Maintenance} />
        <Route path="/analytics" component={Analytics} />
        <Route path="/system-integration" component={SystemIntegration} />
        <Route path="/kiosk-display" component={KioskDisplay} />
        <Route path="/trailer-management" component={TrailerManagement} />
        <Route path="/dock-employee-dashboard" component={DockEmployeeDashboard} />
        <Route path="/admin" component={AdminPanel} />
        <Route path="/docks/:id" component={DockDetail} />
        <Route component={NotFound} />
      </Switch>
    </>
  );
}

export default App;
