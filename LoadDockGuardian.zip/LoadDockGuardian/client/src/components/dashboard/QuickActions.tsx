import React from 'react';
import { Button } from '@/components/ui/button';
import { Link } from 'wouter';
import { PlusCircle, AlertTriangle, Clock, HelpCircle } from 'lucide-react';

interface QuickActionButtonProps {
  icon: React.ReactNode;
  label: string;
  onClick?: () => void;
  href?: string;
}

const QuickActionButton: React.FC<QuickActionButtonProps> = ({ 
  icon, 
  label, 
  onClick,
  href
}) => {
  const buttonContent = (
    <div className="bg-white p-4 rounded-lg border border-gray-200 flex flex-col items-center justify-center hover:bg-gray-50 text-safety-blue h-full">
      <div className="mb-2">{icon}</div>
      <span className="text-sm">{label}</span>
    </div>
  );

  if (href) {
    return (
      <Link href={href}>
        <a className="block h-full">{buttonContent}</a>
      </Link>
    );
  }

  return (
    <Button 
      variant="ghost" 
      className="p-0 h-auto w-full"
      onClick={onClick}
    >
      {buttonContent}
    </Button>
  );
};

interface QuickActionsProps {
  onScheduleCheck?: () => void;
  onRequestHelp?: () => void;
}

const QuickActions: React.FC<QuickActionsProps> = ({
  onScheduleCheck,
  onRequestHelp
}) => {
  return (
    <div className="bg-neutral-light rounded-lg border border-gray-300 p-5">
      <h3 className="text-lg font-bold mb-4">Quick Actions</h3>
      
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <QuickActionButton 
          icon={<PlusCircle className="h-6 w-6" />}
          label="New Vehicle"
          href="/vehicles/new"
        />
        
        <QuickActionButton 
          icon={<AlertTriangle className="h-6 w-6" />}
          label="Report Issue"
          href="/incidents/new"
        />
        
        <QuickActionButton 
          icon={<Clock className="h-6 w-6" />}
          label="Schedule Check"
          onClick={onScheduleCheck}
        />
        
        <QuickActionButton 
          icon={<HelpCircle className="h-6 w-6" />}
          label="Request Help"
          onClick={onRequestHelp}
        />
      </div>
    </div>
  );
};

export default QuickActions;
