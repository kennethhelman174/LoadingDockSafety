import React from 'react';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { useLocation } from 'wouter';
import { AlertCircle, Check, Clock, Truck, Eye } from 'lucide-react';

interface StatusIndicatorProps {
  status: 'safe' | 'caution' | 'danger' | 'available';
  label: string;
}

const StatusIndicator: React.FC<StatusIndicatorProps> = ({ status, label }) => {
  const getStatusColors = () => {
    switch (status) {
      case 'safe':
        return 'bg-green-500 text-black dark:bg-green-600 dark:text-white';
      case 'caution':
        return 'bg-amber-500 text-black dark:bg-amber-600 dark:text-white';
      case 'danger':
        return 'bg-red-500 text-black dark:bg-red-600 dark:text-white';
      case 'available':
      default:
        return 'bg-gray-500 text-white dark:bg-gray-600';
    }
  };

  return (
    <span className={`${getStatusColors()} text-xs px-2 py-1 rounded-full font-bold`}>
      {label}
    </span>
  );
};

interface CheckItemProps {
  icon: React.ReactNode;
  text: string;
  status: 'success' | 'warning' | 'error' | 'neutral';
}

const CheckItem: React.FC<CheckItemProps> = ({ icon, text, status }) => {
  const getStatusClass = () => {
    switch (status) {
      case 'success':
        return 'text-green-500 dark:text-green-600';
      case 'warning':
        return 'text-amber-500 dark:text-amber-600';
      case 'error':
        return 'text-red-500 dark:text-red-600';
      case 'neutral':
      default:
        return 'text-gray-400 dark:text-gray-500';
    }
  };

  return (
    <div className="flex items-center">
      <span className={`mr-2 ${getStatusClass()}`}>{icon}</span>
      <span className={status === 'neutral' ? 'text-gray-500' : ''}>{text}</span>
    </div>
  );
};

interface DockStatusCardProps {
  id: number;
  name: string;
  status: 'safe' | 'caution' | 'danger' | 'available';
  timeInfo: string;
  trailerInfo?: string;
  checkItems: {
    text: string;
    status: 'success' | 'warning' | 'error' | 'neutral';
  }[];
  onManage?: () => void;
  onViewDetails?: () => void;
}

const DockStatusCard: React.FC<DockStatusCardProps> = ({
  id,
  name,
  status,
  timeInfo,
  trailerInfo,
  checkItems,
  onManage,
  onViewDetails,
}) => {
  const [, navigate] = useLocation();
  
  const getStatusLabel = () => {
    switch (status) {
      case 'safe': return 'SAFE';
      case 'caution': return 'CAUTION';
      case 'danger': return 'DANGER';
      case 'available': return 'AVAILABLE';
    }
  };
  
  const getBorderColor = () => {
    switch (status) {
      case 'safe': return 'border-green-500 dark:border-green-600';
      case 'caution': return 'border-amber-500 dark:border-amber-600';
      case 'danger': return 'border-red-500 dark:border-red-600';
      case 'available': return 'border-gray-300 dark:border-gray-700';
    }
  };
  
  const handleManage = () => {
    if (onManage) {
      onManage();
    } else {
      navigate(`/checklists?dock=${id}`);
    }
  };
  
  const getActionButton = () => {
    if (status === 'danger') {
      return (
        <Button 
          variant="destructive"
          onClick={() => navigate(`/incidents/new?dock=${id}`)}
        >
          Report Issue
        </Button>
      );
    }
    
    return (
      <Button 
        variant="default"
        onClick={handleManage}
      >
        {status === 'available' ? 'Assign' : 'Manage'}
      </Button>
    );
  };
  
  return (
    <Card className={`overflow-hidden border-t-4 ${getBorderColor()}`}>
      <div className="p-4">
        <div className="flex justify-between items-center mb-2">
          <h4 className="font-bold text-lg">{name}</h4>
          <StatusIndicator status={status} label={getStatusLabel()} />
        </div>
        
        <div className="text-sm mb-3">
          <p className="flex items-center text-gray-700 dark:text-gray-300">
            <Clock className="h-4 w-4 mr-1" />
            <span>{timeInfo}</span>
          </p>
          {trailerInfo && (
            <p className="flex items-center text-gray-700 dark:text-gray-300">
              <Truck className="h-4 w-4 mr-1" />
              <span>{trailerInfo}</span>
            </p>
          )}
        </div>
        
        <div className="space-y-2">
          {checkItems.map((item, index) => (
            <CheckItem 
              key={index}
              icon={
                item.status === 'success' ? <Check size={16} /> :
                item.status === 'warning' ? <AlertCircle size={16} /> :
                item.status === 'error' ? <AlertCircle size={16} /> :
                <Check size={16} />
              }
              text={item.text}
              status={item.status}
            />
          ))}
        </div>
      </div>
      
      <div className="bg-gray-100 dark:bg-gray-800 p-3 flex justify-between">
        <Button 
          variant="ghost"
          size="sm"
          className="text-gray-600 dark:text-gray-300 text-sm flex items-center"
          onClick={() => window.location.href = `/docks/${id}`}
        >
          <Eye className="h-4 w-4 mr-1" />
          Details
        </Button>
        
        {getActionButton()}
      </div>
    </Card>
  );
};

export default DockStatusCard;
