import React from 'react';
import { Card, CardHeader, CardTitle, CardContent, CardFooter } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { History, ChevronRight, CheckCircle, AlertTriangle, AlertCircle, Truck } from 'lucide-react';
import { cn } from '@/lib/utils';

export interface ActivityItem {
  id: number;
  type: 'success' | 'warning' | 'error' | 'info';
  title: string;
  description: string;
  time: string;
}

interface ActivityLogProps {
  activities: ActivityItem[];
  onViewAll?: () => void;
}

const ActivityLog: React.FC<ActivityLogProps> = ({ 
  activities,
  onViewAll
}) => {
  const getActivityIcon = (type: ActivityItem['type']) => {
    switch (type) {
      case 'success':
        return <CheckCircle className="text-green-500 dark:text-green-400 bg-green-100 dark:bg-green-900/30 p-1 rounded-full" />;
      case 'warning':
        return <AlertTriangle className="text-amber-500 dark:text-amber-400 bg-amber-100 dark:bg-amber-900/30 p-1 rounded-full" />;
      case 'error':
        return <AlertCircle className="text-red-500 dark:text-red-400 bg-red-100 dark:bg-red-900/30 p-1 rounded-full" />;
      case 'info':
      default:
        return <Truck className="text-gray-500 dark:text-gray-400 bg-gray-100 dark:bg-gray-800 p-1 rounded-full" />;
    }
  };

  const getBorderColor = (type: ActivityItem['type']) => {
    switch (type) {
      case 'success':
        return 'border-green-500 dark:border-green-600';
      case 'warning':
        return 'border-amber-500 dark:border-amber-600';
      case 'error':
        return 'border-red-500 dark:border-red-600';
      case 'info':
      default:
        return 'border-gray-300 dark:border-gray-700';
    }
  };

  return (
    <Card>
      <CardHeader className="pb-3">
        <CardTitle className="flex items-center text-xl font-bold">
          <History className="mr-2 h-5 w-5 text-primary" />
          Recent Activity
        </CardTitle>
      </CardHeader>
      
      <CardContent className="space-y-4">
        {activities.map((activity) => (
          <div 
            key={activity.id} 
            className={cn(
              "flex items-start border-l-4 pl-4 py-1",
              getBorderColor(activity.type)
            )}
          >
            <div className="mr-3">
              {getActivityIcon(activity.type)}
            </div>
            <div>
              <p className="font-medium">{activity.title}</p>
              <p className="text-sm text-gray-600">{activity.description}</p>
              <p className="text-xs text-gray-500">{activity.time}</p>
            </div>
          </div>
        ))}
      </CardContent>
      
      <CardFooter>
        <Button 
          variant="ghost" 
          className="text-safety-blue flex items-center w-full justify-center"
          onClick={onViewAll}
        >
          <span>View full activity log</span>
          <ChevronRight className="ml-1 h-4 w-4" />
        </Button>
      </CardFooter>
    </Card>
  );
};

export default ActivityLog;
