import React from 'react';
import { AlertTriangle, X } from 'lucide-react';
import { Button } from '@/components/ui/button';

interface AlertBannerProps {
  title: string;
  message: string;
  onClose?: () => void;
}

const AlertBanner: React.FC<AlertBannerProps> = ({ title, message, onClose }) => {
  return (
    <div className="bg-safety-red text-white p-4 rounded-md shadow-md flex items-start mb-6 animate-in fade-in slide-in-from-top-5 duration-300">
      <AlertTriangle className="mr-2 h-6 w-6 flex-shrink-0" />
      <div>
        <h3 className="font-bold">{title}</h3>
        <p>{message}</p>
      </div>
      {onClose && (
        <Button 
          variant="ghost" 
          size="icon" 
          className="ml-auto text-white hover:bg-red-600"
          onClick={onClose}
          aria-label="Close alert"
        >
          <X className="h-5 w-5" />
        </Button>
      )}
    </div>
  );
};

export default AlertBanner;
