import React from 'react';
import { Card, CardHeader, CardTitle, CardContent, CardFooter } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { BarChart } from 'lucide-react';
import { Progress } from '@/components/ui/progress';

interface SafetyMetricsProps {
  daysSinceLastIncident: number;
  safetyScore: number;
  checklistCompletionRate: number;
  previousRecord: number;
  onViewFullReport?: () => void;
}

const SafetyMetrics: React.FC<SafetyMetricsProps> = ({
  daysSinceLastIncident,
  safetyScore,
  checklistCompletionRate,
  previousRecord,
  onViewFullReport,
}) => {
  const getSafetyScoreColor = (score: number) => {
    if (score >= 90) return 'bg-green-500 dark:bg-green-600';
    if (score >= 70) return 'bg-amber-500 dark:bg-amber-600';
    return 'bg-red-500 dark:bg-red-600';
  };

  const getCompletionRateColor = (rate: number) => {
    if (rate >= 95) return 'bg-green-500 dark:bg-green-600';
    if (rate >= 80) return 'bg-amber-500 dark:bg-amber-600';
    return 'bg-red-500 dark:bg-red-600';
  };

  return (
    <Card>
      <CardHeader className="pb-3">
        <CardTitle className="flex items-center text-xl font-bold">
          <BarChart className="mr-2 h-5 w-5 text-primary" />
          Safety Metrics
        </CardTitle>
      </CardHeader>
      
      <CardContent className="space-y-6">
        {/* Days Since Last Incident */}
        <div className="text-center p-4 border border-gray-200 dark:border-gray-700 rounded-lg">
          <p className="text-gray-600 dark:text-gray-400 text-sm font-medium">Days Without Incidents</p>
          <p className="text-4xl font-bold text-primary mt-2">{daysSinceLastIncident}</p>
          <p className="text-xs text-gray-500 dark:text-gray-400 mt-1">Previous record: {previousRecord} days</p>
        </div>
        
        {/* Safety Score */}
        <div>
          <div className="flex justify-between mb-1">
            <span className="text-sm font-medium">Monthly Safety Score</span>
            <span className="text-sm font-medium">{safetyScore}%</span>
          </div>
          <div className="h-2.5 bg-gray-200 dark:bg-gray-700 rounded-full w-full overflow-hidden">
            <div 
              className={`h-full ${getSafetyScoreColor(safetyScore)}`} 
              style={{ width: `${safetyScore}%` }}
            />
          </div>
          <p className="text-xs text-gray-500 mt-1">Target: 95% or higher</p>
        </div>
        
        {/* Checklist Completion */}
        <div>
          <div className="flex justify-between mb-1">
            <span className="text-sm font-medium">Checklist Completion Rate</span>
            <span className="text-sm font-medium">{checklistCompletionRate}%</span>
          </div>
          <div className="h-2.5 bg-gray-200 dark:bg-gray-700 rounded-full w-full overflow-hidden">
            <div 
              className={`h-full ${getCompletionRateColor(checklistCompletionRate)}`} 
              style={{ width: `${checklistCompletionRate}%` }}
            />
          </div>
          <p className="text-xs text-gray-500 mt-1">Target: 100%</p>
        </div>
      </CardContent>
      
      <CardFooter>
        <Button 
          className="w-full bg-safety-blue text-white hover:bg-blue-700"
          onClick={onViewFullReport}
        >
          View Full Report
        </Button>
      </CardFooter>
    </Card>
  );
};

export default SafetyMetrics;
