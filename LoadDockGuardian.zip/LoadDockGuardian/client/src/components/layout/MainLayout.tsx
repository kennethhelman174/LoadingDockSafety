import React, { useState } from 'react';
import Sidebar from './Sidebar';
import { Menu, X } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { NotificationsPanel } from '@/components/notifications/NotificationsPanel';
import { ThemeToggle } from '@/components/theme/ThemeToggle';

interface MainLayoutProps {
  children: React.ReactNode;
  title: string;
  description?: string;
}

const MainLayout: React.FC<MainLayoutProps> = ({ 
  children, 
  title,
  description
}) => {
  const [sidebarOpen, setSidebarOpen] = useState(false);

  const toggleSidebar = () => {
    setSidebarOpen(!sidebarOpen);
  };

  return (
    <div className="flex flex-col md:flex-row h-screen">
      {/* Sidebar - hidden on mobile when closed */}
      <div className={`md:block ${sidebarOpen ? 'block' : 'hidden'} fixed inset-0 z-50 md:static md:z-auto`}>
        <Sidebar onClose={() => setSidebarOpen(false)} />
      </div>
      
      {/* Main Content */}
      <main className="flex-grow overflow-auto">
        {/* Mobile Header */}
        <header className="bg-background shadow-md p-4 flex md:hidden items-center justify-between">
          <div className="flex items-center">
            <div className="safety-stripes h-8 w-8 rounded-md mr-3"></div>
            <h1 className="font-bold text-xl">DockSafe</h1>
          </div>
          <div className="flex items-center space-x-2">
            <NotificationsPanel />
            <ThemeToggle />
            <Button 
              variant="ghost" 
              size="icon" 
              onClick={toggleSidebar}
              aria-label={sidebarOpen ? "Close sidebar" : "Open sidebar"}
            >
              {sidebarOpen ? <X /> : <Menu />}
            </Button>
          </div>
        </header>
        
        {/* Desktop Header - visible on medium screens and above */}
        <header className="hidden md:flex bg-background shadow-sm p-4 items-center justify-between">
          <div className="mb-0">
            <h2 className="text-2xl font-bold text-primary">{title}</h2>
            {description && <p className="text-muted-foreground">{description}</p>}
          </div>
          <div className="flex items-center space-x-2">
            <ThemeToggle />
            <NotificationsPanel />
          </div>
        </header>
        
        {/* Page Content */}
        <div className="p-6">
          {/* Mobile Page Header - only visible on small screens */}
          <div className="mb-6 md:hidden">
            <h2 className="text-2xl font-bold text-primary">{title}</h2>
            {description && <p className="text-muted-foreground">{description}</p>}
          </div>
          
          {/* Page Content */}
          {children}
        </div>
      </main>
    </div>
  );
};

export default MainLayout;
