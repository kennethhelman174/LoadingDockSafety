import React, { useEffect, useState } from 'react';
import { 
  subscribeToNotifications,
  type SafetyNotification
} from '@/lib/websocket';
import { 
  Bell,
  X,
  AlertCircle,
  AlertTriangle, 
  CheckCircle,
  Info
} from 'lucide-react';
import {
  Sheet,
  SheetContent,
  SheetHeader,
  SheetTitle,
  SheetTrigger,
  SheetClose,
} from "@/components/ui/sheet";
import { SafetyAlert } from './NotificationCenter';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';

export function NotificationsPanel() {
  const [notifications, setNotifications] = useState<SafetyNotification[]>([]);
  const [unreadCount, setUnreadCount] = useState(0);
  const [isOpen, setIsOpen] = useState(false);

  useEffect(() => {
    // Subscribe to notifications
    const unsubscribe = subscribeToNotifications((notification) => {
      if (notification.type === 'safety_alert') {
        // Add new safety alert to our state
        setNotifications(prev => [notification, ...prev].slice(0, 20)); // Keep only 20 most recent
        if (!isOpen) {
          setUnreadCount(prev => prev + 1);
        }
      }
    });

    return unsubscribe;
  }, [isOpen]);

  const handleOpen = (open: boolean) => {
    setIsOpen(open);
    if (open) {
      setUnreadCount(0);
    }
  };

  const clearAllNotifications = () => {
    setNotifications([]);
    setUnreadCount(0);
  };

  return (
    <Sheet open={isOpen} onOpenChange={handleOpen}>
      <SheetTrigger asChild>
        <Button variant="outline" size="icon" className="relative">
          <Bell className="h-5 w-5" />
          {unreadCount > 0 && (
            <Badge variant="destructive" className="absolute -top-2 -right-2 h-5 w-5 flex items-center justify-center p-0">
              {unreadCount > 9 ? '9+' : unreadCount}
            </Badge>
          )}
        </Button>
      </SheetTrigger>
      <SheetContent>
        <SheetHeader className="flex flex-row items-center justify-between">
          <SheetTitle>Safety Notifications</SheetTitle>
          <div className="flex items-center space-x-2">
            <Button variant="outline" size="sm" onClick={clearAllNotifications}>
              Clear All
            </Button>
            <SheetClose asChild>
              <Button variant="ghost" size="icon">
                <X className="h-5 w-5" />
              </Button>
            </SheetClose>
          </div>
        </SheetHeader>
        
        <div className="mt-6 flex flex-col space-y-4 overflow-y-auto max-h-[calc(100vh-150px)]">
          {notifications.length === 0 ? (
            <div className="text-center py-10 text-muted-foreground">
              <Bell className="mx-auto h-10 w-10 mb-2 opacity-50" />
              <p>No notifications yet</p>
              <p className="text-sm">You'll see safety alerts here when they occur</p>
            </div>
          ) : (
            notifications.map((notification, index) => (
              <SafetyAlert key={`${notification.timestamp}-${index}`} notification={notification} />
            ))
          )}
        </div>
      </SheetContent>
    </Sheet>
  );
}