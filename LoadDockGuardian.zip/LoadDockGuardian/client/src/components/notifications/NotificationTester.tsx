import React from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { useToast } from '@/hooks/use-toast';
import { useMutation } from '@tanstack/react-query';

export function NotificationTester() {
  const { toast } = useToast();

  // Test incident notification mutation
  const testIncidentMutation = useMutation({
    mutationFn: async () => {
      const response = await fetch('/api/incidents', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          title: "Test Safety Incident",
          description: "This is a test incident created to test the notification system",
          severity: "medium",
          status: "open",
          reportedBy: 1,
          dockId: 5,
          reportedAt: new Date().toISOString()
        }),
      });
      
      if (!response.ok) {
        throw new Error('Failed to create test incident');
      }
      
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Test incident created",
        description: "A test incident was reported to demonstrate notifications",
      });
    },
    onError: (error) => {
      console.error('Failed to create test incident:', error);
      toast({
        title: "Error",
        description: "Failed to create test incident",
        variant: "destructive",
      });
    }
  });

  // Test dock status change mutation
  const testDockStatusMutation = useMutation({
    mutationFn: async () => {
      // First, get the current dock
      const dockResponse = await fetch('/api/docks/5');
      if (!dockResponse.ok) {
        throw new Error('Failed to fetch dock information');
      }
      
      const dock = await dockResponse.json();
      
      // Toggle the status between "in_use" and "caution"
      const newStatus = dock.status === "in_use" ? "caution" : "in_use";
      
      const updateResponse = await fetch(`/api/docks/5`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          ...dock,
          status: newStatus
        }),
      });
      
      if (!updateResponse.ok) {
        throw new Error('Failed to update dock status');
      }
      
      return { dock: await updateResponse.json(), newStatus };
    },
    onSuccess: (data) => {
      toast({
        title: "Dock status changed",
        description: `Dock status changed to ${data.newStatus} to demonstrate notifications`,
      });
    },
    onError: (error) => {
      console.error('Failed to update dock status:', error);
      toast({
        title: "Error",
        description: "Failed to update dock status",
        variant: "destructive",
      });
    }
  });

  return (
    <Card className="w-full">
      <CardHeader>
        <CardTitle>Notification Testing</CardTitle>
        <CardDescription>
          Use these buttons to test different types of real-time notifications
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-2">
        <p className="text-sm text-gray-500">
          This panel lets you generate various safety events to test the notification system.
          Click any button below to trigger the corresponding notification type.
        </p>
      </CardContent>
      <CardFooter className="flex flex-wrap gap-2">
        <Button 
          variant="outline" 
          onClick={() => testIncidentMutation.mutate()}
          disabled={testIncidentMutation.isPending}
        >
          {testIncidentMutation.isPending ? "Creating..." : "Test Incident Notification"}
        </Button>
        <Button 
          variant="outline" 
          onClick={() => testDockStatusMutation.mutate()}
          disabled={testDockStatusMutation.isPending}
        >
          {testDockStatusMutation.isPending ? "Updating..." : "Test Dock Status Notification"}
        </Button>
      </CardFooter>
    </Card>
  );
}