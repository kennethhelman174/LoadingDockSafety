import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsList, TabsTrigger, TabsContent } from '@/components/ui/tabs';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { 
  Select, 
  SelectContent, 
  SelectItem, 
  SelectTrigger, 
  SelectValue 
} from '@/components/ui/select';
import { Switch } from '@/components/ui/switch';
import { Checkbox } from '@/components/ui/checkbox';
import { 
  ArrowLeftRight, 
  Check, 
  Clock, 
  Database, 
  FileWarning, 
  Link as LinkIcon,
  Link2Off,
  RefreshCw, 
  Settings, 
  Shield, 
  Truck, 
  Upload, 
  Warehouse
} from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import { useToast } from '@/hooks/use-toast';

// Sample integration systems available
const integrationSystems = [
  { id: 'sap', name: 'SAP Warehouse Management', icon: 'SAP', status: 'disconnected' },
  { id: 'oracle', name: 'Oracle WMS', icon: 'Oracle', status: 'connected' },
  { id: 'manhattan', name: 'Manhattan SCALE', icon: 'Manhattan', status: 'disconnected' },
  { id: 'jda', name: 'JDA Warehouse Management', icon: 'JDA', status: 'disconnected' },
  { id: 'infor', name: 'Infor SCM', icon: 'Infor', status: 'connected' },
];

// Sample data endpoints available for integration
const dataEndpoints = [
  { id: 'inbound', name: 'Inbound Shipments', direction: 'in', enabled: true },
  { id: 'outbound', name: 'Outbound Shipments', direction: 'out', enabled: true },
  { id: 'inventory', name: 'Inventory Levels', direction: 'in', enabled: false },
  { id: 'picking', name: 'Picking Operations', direction: 'in', enabled: false },
  { id: 'safety', name: 'Safety Incidents', direction: 'out', enabled: true },
  { id: 'equipment', name: 'Equipment Status', direction: 'out', enabled: true },
  { id: 'personnel', name: 'Personnel Assignments', direction: 'both', enabled: false },
  { id: 'analytics', name: 'Safety Analytics', direction: 'out', enabled: true },
];

// Sample data mappings between systems
const dataMappings = [
  { source: 'DockSafe.vehicle.id', target: 'WMS.shipment.external_id', status: 'mapped' },
  { source: 'DockSafe.dock.id', target: 'WMS.location.dock_id', status: 'mapped' },
  { source: 'DockSafe.incident.description', target: 'WMS.event.description', status: 'mapped' },
  { source: 'DockSafe.checklist.status', target: 'WMS.quality.checkpoint_status', status: 'mapped' },
  { source: 'DockSafe.safety_score', target: 'WMS.metrics.compliance_score', status: 'mapped' },
  { source: 'WMS.shipment.status', target: 'DockSafe.vehicle.wms_status', status: 'unmapped' },
  { source: 'WMS.schedule.arrival_time', target: 'DockSafe.vehicle.scheduled_arrival', status: 'unmapped' },
  { source: 'WMS.schedule.dock_assignment', target: 'DockSafe.dock.assignment', status: 'unmapped' },
];

// Sample sync logs
const syncLogs = [
  { id: 1, timestamp: '2025-05-19T09:35:12Z', event: 'Push Safety Score', status: 'success', system: 'Oracle WMS', message: 'Successfully pushed safety scores to Oracle WMS' },
  { id: 2, timestamp: '2025-05-19T09:30:05Z', event: 'Pull Inbound Shipments', status: 'success', system: 'Oracle WMS', message: '23 new shipments imported from Oracle WMS' },
  { id: 3, timestamp: '2025-05-19T08:45:22Z', event: 'Push Incident Report', status: 'error', system: 'Oracle WMS', message: 'Field mismatch: incident.severity not recognized' },
  { id: 4, timestamp: '2025-05-19T08:15:00Z', event: 'Push Equipment Status', status: 'success', system: 'Infor SCM', message: 'Updated 5 dock equipment status records' },
  { id: 5, timestamp: '2025-05-19T08:00:00Z', event: 'System Sync', status: 'success', system: 'All Connected', message: 'Scheduled full system sync completed' },
  { id: 6, timestamp: '2025-05-18T17:30:15Z', event: 'Pull Outbound Shipments', status: 'warning', system: 'Infor SCM', message: '3 shipments with missing carrier information' },
  { id: 7, timestamp: '2025-05-18T16:45:32Z', event: 'Authentication', status: 'success', system: 'Infor SCM', message: 'API key renewed successfully' },
  { id: 8, timestamp: '2025-05-18T14:22:10Z', event: 'Push Safety Score', status: 'success', system: 'Infor SCM', message: 'Successfully pushed safety scores to Infor SCM' },
];

interface ApiSettingsFormValues {
  url: string;
  apiKey: string;
  refreshRate: string;
  syncStrategy: string;
  apiVersion: string;
}

const WarehouseSystemIntegration: React.FC = () => {
  const [activeSystem, setActiveSystem] = useState('oracle');
  const [isConnecting, setIsConnecting] = useState(false);
  const [formValues, setFormValues] = useState<ApiSettingsFormValues>({
    url: 'https://api.oraclewms.example.com/v2',
    apiKey: '********-****-****-****-************',
    refreshRate: '15',
    syncStrategy: 'incremental',
    apiVersion: 'v2'
  });
  const { toast } = useToast();
  
  // Handle connecting to a system
  const handleConnect = (systemId: string) => {
    setIsConnecting(true);
    
    // Simulate connection delay
    setTimeout(() => {
      setIsConnecting(false);
      
      // Update local state to show connected
      const updatedSystems = integrationSystems.map(system => 
        system.id === systemId 
          ? { ...system, status: 'connected' } 
          : system
      );
      
      toast({
        title: "Connection Successful",
        description: `Successfully connected to ${integrationSystems.find(s => s.id === systemId)?.name}`,
      });
      
      setActiveSystem(systemId);
    }, 1500);
  };
  
  // Handle disconnecting from a system
  const handleDisconnect = (systemId: string) => {
    // Simulate disconnection
    setTimeout(() => {
      // Update local state to show disconnected
      const updatedSystems = integrationSystems.map(system => 
        system.id === systemId 
          ? { ...system, status: 'disconnected' } 
          : system
      );
      
      toast({
        title: "Disconnected",
        description: `Disconnected from ${integrationSystems.find(s => s.id === systemId)?.name}`,
      });
    }, 800);
  };
  
  // Handle form value changes
  const handleFormChange = (field: keyof ApiSettingsFormValues, value: string) => {
    setFormValues({
      ...formValues,
      [field]: value,
    });
  };
  
  // Handle saving API settings
  const handleSaveSettings = () => {
    toast({
      title: "Settings Saved",
      description: "Integration settings have been updated successfully",
    });
  };
  
  // Handle endpoint toggle
  const handleEndpointToggle = (endpointId: string, enabled: boolean) => {
    // Update local state
    const updatedEndpoints = dataEndpoints.map(endpoint => 
      endpoint.id === endpointId 
        ? { ...endpoint, enabled } 
        : endpoint
    );
    
    toast({
      title: enabled ? "Endpoint Enabled" : "Endpoint Disabled",
      description: `${dataEndpoints.find(e => e.id === endpointId)?.name} is now ${enabled ? 'enabled' : 'disabled'}`,
    });
  };
  
  // Handle data mapping
  const handleMapField = (index: number) => {
    // Update local state
    const updatedMappings = [...dataMappings];
    updatedMappings[index] = {
      ...updatedMappings[index],
      status: 'mapped',
    };
    
    toast({
      title: "Field Mapped",
      description: `Successfully mapped ${dataMappings[index].source} to ${dataMappings[index].target}`,
    });
  };
  
  // Handle manual sync
  const handleManualSync = () => {
    toast({
      title: "Sync Started",
      description: "Manual synchronization has been initiated",
    });
    
    // Simulate sync
    setTimeout(() => {
      toast({
        title: "Sync Completed",
        description: "Data synchronization completed successfully",
      });
    }, 2500);
  };
  
  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold flex items-center">
          <Warehouse className="mr-2 h-6 w-6 text-primary" />
          Warehouse Management System Integration
        </h2>
        <Button 
          onClick={handleManualSync}
          className="flex items-center"
        >
          <RefreshCw className="mr-2 h-4 w-4" />
          Manual Sync
        </Button>
      </div>
      
      <div className="grid grid-cols-1 xl:grid-cols-3 gap-6">
        {/* Available Systems */}
        <Card className="xl:col-span-1">
          <CardHeader>
            <CardTitle className="flex items-center text-lg">
              <Database className="mr-2 h-5 w-5" />
              Available Systems
            </CardTitle>
            <CardDescription>
              Connect to your warehouse management systems
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {integrationSystems.map((system) => (
                <div 
                  key={system.id}
                  className={`p-4 rounded-lg border flex justify-between items-center ${
                    system.status === 'connected' 
                      ? 'bg-green-50 dark:bg-green-900/20 border-green-200 dark:border-green-800' 
                      : 'bg-gray-50 dark:bg-gray-800/50'
                  } ${activeSystem === system.id ? 'ring-2 ring-primary' : ''}`}
                  onClick={() => system.status === 'connected' && setActiveSystem(system.id)}
                >
                  <div className="flex items-center">
                    <div className="w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center text-primary text-xs font-bold">
                      {system.icon.substring(0, 2)}
                    </div>
                    <div className="ml-3">
                      <h4 className="font-medium text-sm">{system.name}</h4>
                      <p className="text-xs text-gray-500 dark:text-gray-400">
                        {system.status === 'connected' ? 'Connected' : 'Not connected'}
                      </p>
                    </div>
                  </div>
                  
                  {system.status === 'connected' ? (
                    <Button 
                      variant="outline" 
                      size="sm"
                      onClick={(e) => {
                        e.stopPropagation();
                        handleDisconnect(system.id);
                      }}
                    >
                      <Link2Off className="h-4 w-4 mr-1" />
                      Disconnect
                    </Button>
                  ) : (
                    <Button 
                      size="sm"
                      onClick={(e) => {
                        e.stopPropagation();
                        handleConnect(system.id);
                      }}
                      disabled={isConnecting}
                    >
                      {isConnecting ? (
                        <>
                          <RefreshCw className="h-4 w-4 mr-1 animate-spin" />
                          Connecting...
                        </>
                      ) : (
                        <>
                          <LinkIcon className="h-4 w-4 mr-1" />
                          Connect
                        </>
                      )}
                    </Button>
                  )}
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
        
        {/* Configuration Tabs */}
        <Card className="xl:col-span-2">
          <Tabs defaultValue="data_mapping">
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle className="flex items-center text-lg">
                  <Settings className="mr-2 h-5 w-5" />
                  System Configuration
                </CardTitle>
                <TabsList>
                  <TabsTrigger value="data_mapping" className="text-xs">Data Mapping</TabsTrigger>
                  <TabsTrigger value="endpoints" className="text-xs">Endpoints</TabsTrigger>
                  <TabsTrigger value="settings" className="text-xs">API Settings</TabsTrigger>
                </TabsList>
              </div>
              <CardDescription>
                Configure integration with {integrationSystems.find(s => s.id === activeSystem)?.name || 'selected system'}
              </CardDescription>
            </CardHeader>
            
            <CardContent>
              {/* Data Mapping Tab */}
              <TabsContent value="data_mapping" className="space-y-4">
                <div className="rounded-md border">
                  <div className="bg-muted/50 p-3 flex font-medium text-sm">
                    <div className="w-5/12">Source Field</div>
                    <div className="w-5/12">Target Field</div>
                    <div className="w-2/12 text-right">Status</div>
                  </div>
                  <div className="divide-y">
                    {dataMappings.map((mapping, index) => (
                      <div key={`${mapping.source}-${mapping.target}`} className="p-3 flex items-center text-sm">
                        <div className="w-5/12 flex items-center">
                          <Badge variant="outline" className="mr-2 font-mono text-xs">
                            {mapping.source.split('.')[0]}
                          </Badge>
                          <span className="text-sm">{mapping.source.split('.').slice(1).join('.')}</span>
                        </div>
                        <div className="w-5/12 flex items-center">
                          <Badge variant="outline" className="mr-2 font-mono text-xs">
                            {mapping.target.split('.')[0]}
                          </Badge>
                          <span className="text-sm">{mapping.target.split('.').slice(1).join('.')}</span>
                        </div>
                        <div className="w-2/12 text-right">
                          {mapping.status === 'mapped' ? (
                            <Badge variant="success" className="bg-green-500">
                              <Check className="h-3 w-3 mr-1" />
                              Mapped
                            </Badge>
                          ) : (
                            <Button 
                              size="sm" 
                              variant="outline"
                              className="text-xs h-7 px-2"
                              onClick={() => handleMapField(index)}
                            >
                              Map Field
                            </Button>
                          )}
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
                
                <div className="bg-yellow-50 dark:bg-yellow-900/20 border border-yellow-200 dark:border-yellow-800 p-3 rounded-md">
                  <div className="flex items-start">
                    <FileWarning className="h-5 w-5 text-yellow-500 mt-0.5 mr-2 flex-shrink-0" />
                    <div>
                      <h4 className="font-medium text-sm">Mapping Validation</h4>
                      <p className="text-sm mt-1 text-gray-600 dark:text-gray-300">
                        Some fields remain unmapped. Missing mappings may cause partial data synchronization
                        between DockSafe and {integrationSystems.find(s => s.id === activeSystem)?.name}.
                      </p>
                    </div>
                  </div>
                </div>
              </TabsContent>
              
              {/* Endpoints Tab */}
              <TabsContent value="endpoints" className="space-y-4">
                <div className="rounded-md border">
                  <div className="bg-muted/50 p-3 flex font-medium text-sm">
                    <div className="w-6/12">Data Endpoint</div>
                    <div className="w-3/12">Direction</div>
                    <div className="w-3/12 text-right">Status</div>
                  </div>
                  <div className="divide-y">
                    {dataEndpoints.map((endpoint) => (
                      <div key={endpoint.id} className="p-3 flex items-center text-sm">
                        <div className="w-6/12">
                          <div className="font-medium">{endpoint.name}</div>
                        </div>
                        <div className="w-3/12">
                          <Badge variant="outline">
                            {endpoint.direction === 'in' && <ArrowLeftRight className="h-3 w-3 mr-1 rotate-180" />}
                            {endpoint.direction === 'out' && <ArrowLeftRight className="h-3 w-3 mr-1" />}
                            {endpoint.direction === 'both' && <ArrowLeftRight className="h-3 w-3 mr-1" />}
                            {endpoint.direction === 'in' && 'Import'}
                            {endpoint.direction === 'out' && 'Export'}
                            {endpoint.direction === 'both' && 'Bidirectional'}
                          </Badge>
                        </div>
                        <div className="w-3/12 text-right">
                          <div className="flex items-center justify-end space-x-2">
                            <div className="text-sm">
                              {endpoint.enabled ? 'Enabled' : 'Disabled'}
                            </div>
                            <Switch
                              checked={endpoint.enabled}
                              onCheckedChange={(checked) => handleEndpointToggle(endpoint.id, checked)}
                            />
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
                
                <div className="bg-blue-50 dark:bg-blue-900/20 border border-blue-200 dark:border-blue-800 p-3 rounded-md">
                  <div className="flex">
                    <Shield className="h-5 w-5 text-blue-500 mt-0.5 mr-2 flex-shrink-0" />
                    <div>
                      <h4 className="font-medium text-sm">Data Security</h4>
                      <p className="text-sm mt-1 text-gray-600 dark:text-gray-300">
                        All data transfers are encrypted using TLS 1.3. Personal information is masked
                        according to your organization's data privacy settings.
                      </p>
                    </div>
                  </div>
                </div>
              </TabsContent>
              
              {/* API Settings Tab */}
              <TabsContent value="settings" className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="api-url">API URL</Label>
                    <Input
                      id="api-url"
                      placeholder="https://api.example.com/v2"
                      value={formValues.url}
                      onChange={(e) => handleFormChange('url', e.target.value)}
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="api-key">API Key</Label>
                    <Input
                      id="api-key"
                      type="password"
                      value={formValues.apiKey}
                      onChange={(e) => handleFormChange('apiKey', e.target.value)}
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="api-version">API Version</Label>
                    <Select 
                      value={formValues.apiVersion}
                      onValueChange={(value) => handleFormChange('apiVersion', value)}
                    >
                      <SelectTrigger id="api-version">
                        <SelectValue placeholder="Select API version" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="v1">Version 1.0</SelectItem>
                        <SelectItem value="v2">Version 2.0</SelectItem>
                        <SelectItem value="v3">Version 3.0 (Beta)</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="refresh-rate">Refresh Rate (minutes)</Label>
                    <Select 
                      value={formValues.refreshRate}
                      onValueChange={(value) => handleFormChange('refreshRate', value)}
                    >
                      <SelectTrigger id="refresh-rate">
                        <SelectValue placeholder="Select refresh rate" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="5">5 minutes</SelectItem>
                        <SelectItem value="15">15 minutes</SelectItem>
                        <SelectItem value="30">30 minutes</SelectItem>
                        <SelectItem value="60">1 hour</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="sync-strategy">Sync Strategy</Label>
                    <Select 
                      value={formValues.syncStrategy}
                      onValueChange={(value) => handleFormChange('syncStrategy', value)}
                    >
                      <SelectTrigger id="sync-strategy">
                        <SelectValue placeholder="Select sync strategy" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="full">Full Sync</SelectItem>
                        <SelectItem value="incremental">Incremental Sync</SelectItem>
                        <SelectItem value="differential">Differential Sync</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  
                  <div className="space-y-2">
                    <Label className="text-sm font-medium mb-1.5 block">Advanced Options</Label>
                    <div className="flex items-center space-x-2">
                      <Checkbox id="secure-only" defaultChecked />
                      <label
                        htmlFor="secure-only"
                        className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                      >
                        Require secure connection
                      </label>
                    </div>
                    <div className="flex items-center space-x-2 mt-2">
                      <Checkbox id="fail-silent" />
                      <label
                        htmlFor="fail-silent"
                        className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                      >
                        Fail silently on errors
                      </label>
                    </div>
                  </div>
                </div>
                
                <div className="mt-4">
                  <Button onClick={handleSaveSettings}>Save API Settings</Button>
                </div>
              </TabsContent>
            </CardContent>
          </Tabs>
        </Card>
      </div>
      
      {/* Sync Logs */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center text-lg">
            <Clock className="mr-2 h-5 w-5" />
            Integration Activity Logs
          </CardTitle>
          <CardDescription>
            Recent data synchronization activity between systems
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="rounded-md border overflow-hidden">
            <table className="min-w-full divide-y divide-gray-200 dark:divide-gray-700">
              <thead className="bg-muted/50">
                <tr>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                    Timestamp
                  </th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                    Event
                  </th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                    System
                  </th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                    Status
                  </th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                    Message
                  </th>
                </tr>
              </thead>
              <tbody className="bg-white dark:bg-gray-900 divide-y divide-gray-200 dark:divide-gray-800">
                {syncLogs.map((log) => (
                  <tr key={log.id}>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900 dark:text-gray-100">
                      {new Date(log.timestamp).toLocaleString()}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500 dark:text-gray-400">
                      <div className="flex items-center">
                        {log.event.includes('Push') && <Upload className="h-4 w-4 mr-1 text-blue-500" />}
                        {log.event.includes('Pull') && <Truck className="h-4 w-4 mr-1 text-green-500" />}
                        {log.event === 'System Sync' && <RefreshCw className="h-4 w-4 mr-1 text-purple-500" />}
                        {log.event === 'Authentication' && <Shield className="h-4 w-4 mr-1 text-amber-500" />}
                        {log.event}
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500 dark:text-gray-400">
                      {log.system}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      {log.status === 'success' && (
                        <Badge variant="success" className="bg-green-500">Success</Badge>
                      )}
                      {log.status === 'error' && (
                        <Badge variant="destructive">Error</Badge>
                      )}
                      {log.status === 'warning' && (
                        <Badge variant="warning" className="bg-yellow-500">Warning</Badge>
                      )}
                    </td>
                    <td className="px-6 py-4 text-sm text-gray-500 dark:text-gray-400">
                      {log.message}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </CardContent>
        <CardFooter className="flex justify-between">
          <Button variant="outline" size="sm">
            Export Logs
          </Button>
          <Button variant="outline" size="sm">
            View All Logs
          </Button>
        </CardFooter>
      </Card>
    </div>
  );
};

export default WarehouseSystemIntegration;