import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsList, TabsTrigger, TabsContent } from '@/components/ui/tabs';
import { Activity, ChevronDown, Clock, Wrench, TrendingUp } from 'lucide-react';
import {
  LineChart,
  Line,
  BarChart,
  Bar,
  PieChart,
  Pie,
  ResponsiveContainer,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  Cell
} from 'recharts';

// Sample data for charts
const monthlyMaintenanceData = [
  { month: 'Jan', preventive: 12, corrective: 5, emergency: 2 },
  { month: 'Feb', preventive: 15, corrective: 7, emergency: 1 },
  { month: 'Mar', preventive: 18, corrective: 4, emergency: 2 },
  { month: 'Apr', preventive: 14, corrective: 8, emergency: 3 },
  { month: 'May', preventive: 20, corrective: 6, emergency: 1 },
  { month: 'Jun', preventive: 22, corrective: 5, emergency: 0 },
];

const typeDistributionData = [
  { name: 'Hydraulic Issues', value: 28, color: '#0ea5e9' },
  { name: 'Electrical Problems', value: 22, color: '#f59e0b' },
  { name: 'Mechanical Wear', value: 35, color: '#10b981' },
  { name: 'Restraint Systems', value: 15, color: '#8b5cf6' },
];

const timeToResolutionData = [
  { name: 'Dock 100-110', avgHours: 4.2 },
  { name: 'Dock 111-120', avgHours: 5.7 },
  { name: 'Dock 121-130', avgHours: 3.8 },
  { name: 'Dock 200-210', avgHours: 6.2 },
  { name: 'Dock 211-220', avgHours: 4.9 },
];

const technicianWorkloadData = [
  { name: 'Carlos Smith', completed: 32, inProgress: 3 },
  { name: 'Maria Johnson', completed: 28, inProgress: 5 },
  { name: 'Alex Rodriguez', completed: 35, inProgress: 2 },
  { name: 'Sarah Williams', completed: 24, inProgress: 4 },
];

const MaintenanceReportingCharts: React.FC = () => {
  return (
    <Card className="w-full">
      <CardHeader>
        <CardTitle className="flex items-center">
          <TrendingUp className="mr-2 h-5 w-5" />
          Maintenance Analytics
        </CardTitle>
      </CardHeader>
      <CardContent>
        <Tabs defaultValue="monthly">
          <TabsList className="grid grid-cols-4 mb-6">
            <TabsTrigger value="monthly" className="text-xs md:text-sm">
              <Activity className="h-4 w-4 mr-1 inline" />
              Monthly Trends
            </TabsTrigger>
            <TabsTrigger value="types" className="text-xs md:text-sm">
              <Wrench className="h-4 w-4 mr-1 inline" />
              Issue Types
            </TabsTrigger>
            <TabsTrigger value="resolution" className="text-xs md:text-sm">
              <Clock className="h-4 w-4 mr-1 inline" />
              Resolution Time
            </TabsTrigger>
            <TabsTrigger value="technicians" className="text-xs md:text-sm">
              <ChevronDown className="h-4 w-4 mr-1 inline" />
              Technician Load
            </TabsTrigger>
          </TabsList>

          {/* Monthly Maintenance Trends */}
          <TabsContent value="monthly" className="space-y-4">
            <h3 className="text-lg font-medium">Monthly Maintenance Activities</h3>
            <p className="text-sm text-gray-500 dark:text-gray-400 mb-4">
              Tracking preventive, corrective, and emergency maintenance over time
            </p>
            <div className="h-80">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={monthlyMaintenanceData} margin={{ top: 5, right: 30, left: 20, bottom: 5 }}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="month" />
                  <YAxis />
                  <Tooltip />
                  <Legend />
                  <Line 
                    type="monotone" 
                    dataKey="preventive" 
                    name="Preventive" 
                    stroke="#10b981" 
                    activeDot={{ r: 8 }} 
                  />
                  <Line 
                    type="monotone" 
                    dataKey="corrective" 
                    name="Corrective" 
                    stroke="#f59e0b" 
                  />
                  <Line 
                    type="monotone" 
                    dataKey="emergency" 
                    name="Emergency" 
                    stroke="#ef4444" 
                  />
                </LineChart>
              </ResponsiveContainer>
            </div>
            <div className="grid grid-cols-3 gap-4 mt-6">
              <div className="bg-green-50 dark:bg-green-900/20 p-3 rounded-md border border-green-100 dark:border-green-900">
                <div className="text-xl font-bold text-green-600 dark:text-green-400">101</div>
                <div className="text-sm text-gray-600 dark:text-gray-400">Preventive Tasks</div>
              </div>
              <div className="bg-amber-50 dark:bg-amber-900/20 p-3 rounded-md border border-amber-100 dark:border-amber-900">
                <div className="text-xl font-bold text-amber-600 dark:text-amber-400">35</div>
                <div className="text-sm text-gray-600 dark:text-gray-400">Corrective Tasks</div>
              </div>
              <div className="bg-red-50 dark:bg-red-900/20 p-3 rounded-md border border-red-100 dark:border-red-900">
                <div className="text-xl font-bold text-red-600 dark:text-red-400">9</div>
                <div className="text-sm text-gray-600 dark:text-gray-400">Emergency Tasks</div>
              </div>
            </div>
          </TabsContent>

          {/* Issue Type Distribution */}
          <TabsContent value="types">
            <h3 className="text-lg font-medium">Maintenance Issue Distribution</h3>
            <p className="text-sm text-gray-500 dark:text-gray-400 mb-4">
              Breakdown of maintenance issues by category
            </p>
            <div className="h-80">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={typeDistributionData}
                    cx="50%"
                    cy="50%"
                    labelLine={true}
                    outerRadius={80}
                    fill="#8884d8"
                    dataKey="value"
                    label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                  >
                    {typeDistributionData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.color} />
                    ))}
                  </Pie>
                  <Tooltip formatter={(value) => [`${value} issues`, 'Count']} />
                  <Legend />
                </PieChart>
              </ResponsiveContainer>
            </div>
            <div className="grid grid-cols-2 gap-4 mt-6">
              <div className="p-3 rounded-md border">
                <div className="text-xl font-bold text-primary">28%</div>
                <div className="text-sm text-gray-600 dark:text-gray-400">Require Parts Order</div>
              </div>
              <div className="p-3 rounded-md border">
                <div className="text-xl font-bold text-primary">6.2hrs</div>
                <div className="text-sm text-gray-600 dark:text-gray-400">Avg. Repair Time</div>
              </div>
            </div>
          </TabsContent>

          {/* Resolution Time */}
          <TabsContent value="resolution">
            <h3 className="text-lg font-medium">Average Resolution Time by Dock Area</h3>
            <p className="text-sm text-gray-500 dark:text-gray-400 mb-4">
              Time to resolve maintenance issues in hours
            </p>
            <div className="h-80">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart
                  data={timeToResolutionData}
                  margin={{ top: 5, right: 30, left: 20, bottom: 5 }}
                >
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="name" />
                  <YAxis label={{ value: 'Hours', angle: -90, position: 'insideLeft' }} />
                  <Tooltip formatter={(value) => [`${value} hours`, 'Resolution Time']} />
                  <Bar dataKey="avgHours" name="Average Hours" fill="#8b5cf6">
                    {timeToResolutionData.map((entry, index) => (
                      <Cell 
                        key={`cell-${index}`} 
                        fill={entry.avgHours > 5 ? '#ef4444' : '#8b5cf6'} 
                      />
                    ))}
                  </Bar>
                </BarChart>
              </ResponsiveContainer>
            </div>
            <div className="p-3 rounded-md border mt-6 bg-indigo-50 dark:bg-indigo-900/20">
              <div className="text-xl font-bold text-indigo-600 dark:text-indigo-400">4.96hrs</div>
              <div className="text-sm text-gray-600 dark:text-gray-400">Overall Average Resolution Time</div>
            </div>
          </TabsContent>

          {/* Technician Workload */}
          <TabsContent value="technicians">
            <h3 className="text-lg font-medium">Technician Workload</h3>
            <p className="text-sm text-gray-500 dark:text-gray-400 mb-4">
              Completed and in-progress tasks per technician
            </p>
            <div className="h-80">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart
                  data={technicianWorkloadData}
                  margin={{ top: 20, right: 30, left: 20, bottom: 5 }}
                  layout="vertical"
                >
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis type="number" />
                  <YAxis dataKey="name" type="category" />
                  <Tooltip />
                  <Legend />
                  <Bar dataKey="completed" name="Completed Tasks" stackId="a" fill="#10b981" />
                  <Bar dataKey="inProgress" name="In Progress" stackId="a" fill="#f59e0b" />
                </BarChart>
              </ResponsiveContainer>
            </div>
            <div className="grid grid-cols-2 gap-4 mt-6">
              <div className="p-3 rounded-md border">
                <div className="text-xl font-bold text-primary">119</div>
                <div className="text-sm text-gray-600 dark:text-gray-400">Total Completed</div>
              </div>
              <div className="p-3 rounded-md border">
                <div className="text-xl font-bold text-primary">14</div>
                <div className="text-sm text-gray-600 dark:text-gray-400">In Progress</div>
              </div>
            </div>
          </TabsContent>
        </Tabs>
      </CardContent>
    </Card>
  );
};

export default MaintenanceReportingCharts;