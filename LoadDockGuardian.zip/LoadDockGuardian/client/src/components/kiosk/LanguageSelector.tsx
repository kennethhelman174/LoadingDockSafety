import React from 'react';
import { Button } from '@/components/ui/button';
import { supportedLanguages, setLanguage, getLanguage } from '@/lib/i18n';

interface LanguageSelectorProps {
  onLanguageChange?: (language: string) => void;
}

const LanguageSelector: React.FC<LanguageSelectorProps> = ({ onLanguageChange }) => {
  const currentLanguage = getLanguage();
  
  const handleLanguageChange = (langCode: string) => {
    setLanguage(langCode as any);
    if (onLanguageChange) {
      onLanguageChange(langCode);
    }
  };
  
  return (
    <div className="flex flex-wrap justify-center gap-2 mb-6">
      {supportedLanguages.map((lang) => (
        <Button
          key={lang.code}
          variant={currentLanguage === lang.code ? "default" : "outline"}
          size="sm"
          onClick={() => handleLanguageChange(lang.code)}
          className="min-w-[100px]"
        >
          {lang.name}
        </Button>
      ))}
    </div>
  );
};

export default LanguageSelector;