import React from 'react';
import { cn } from '@/lib/utils';

interface SafetyToggleProps extends React.InputHTMLAttributes<HTMLInputElement> {
  id: string;
  label?: string;
  description?: string;
  icon?: string;
  onToggle?: (checked: boolean) => void;
}

const SafetyToggle: React.FC<SafetyToggleProps> = ({
  id,
  label,
  description,
  icon = 'fact_check',
  className,
  checked,
  onChange,
  onToggle,
  ...props
}) => {
  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    onChange?.(e);
    onToggle?.(e.target.checked);
  };

  return (
    <div className={cn("flex items-center justify-between p-2", className)}>
      <div className="flex items-start">
        {icon && <span className="material-icons text-safety-blue mr-2 mt-0.5">{icon}</span>}
        <div>
          {label && <p className="font-medium">{label}</p>}
          {description && <p className="text-sm text-gray-600">{description}</p>}
        </div>
      </div>
      <div className="relative inline-block w-12 align-middle select-none">
        <input
          type="checkbox"
          id={id}
          checked={checked}
          onChange={handleChange}
          className="absolute block w-6 h-6 rounded-full bg-white border-4 appearance-none cursor-pointer transition-transform duration-200 ease-in-out 
            checked:translate-x-6 checked:border-safety-green peer"
          {...props}
        />
        <label
          htmlFor={id}
          className="block overflow-hidden h-6 rounded-full bg-gray-300 cursor-pointer peer-checked:bg-safety-green transition-colors duration-200 ease-in-out"
        ></label>
      </div>
    </div>
  );
};

export default SafetyToggle;
