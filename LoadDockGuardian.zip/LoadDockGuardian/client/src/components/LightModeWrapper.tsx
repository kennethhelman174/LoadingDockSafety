import React from "react";

interface LightModeWrapperProps {
  children: React.ReactNode;
}

/**
 * This component forces a light mode theme for its children,
 * making sure all text and backgrounds appear properly regardless
 * of the application's current theme
 */
export function LightModeWrapper({ children }: LightModeWrapperProps) {
  return (
    <div 
      className="light-mode-wrapper" 
      style={{ 
        backgroundColor: "white",
        color: "black",
        borderRadius: "0.5rem",
        padding: "1rem",
      }}
    >
      {children}
    </div>
  );
}