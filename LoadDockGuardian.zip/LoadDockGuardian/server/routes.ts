import type { Express, Request, Response } from "express";
import { createServer, type Server } from "http";
import { WebSocketServer, WebSocket } from "ws";
import { storage } from "./storage";
import { 
  insertChecklistItemSchema, 
  insertCompletedChecklistSchema, 
  insertDockSchema, 
  insertIncidentSchema, 
  insertVehicleSchema,
  insertActivityLogSchema
} from "@shared/schema";
import { z } from "zod";

// Store connected clients
const clients = new Set<WebSocket>();

// Function to broadcast messages to all connected clients
function broadcastNotification(data: any) {
  clients.forEach(client => {
    if (client.readyState === WebSocket.OPEN) {
      client.send(JSON.stringify(data));
    }
  });
}

// Helper function to determine severity from dock status
function getSeverityFromDockStatus(status: string): 'success' | 'info' | 'warning' | 'error' {
  switch (status) {
    case 'danger':
      return 'error';
    case 'caution':
      return 'warning';
    case 'in_use':
      return 'info';
    case 'available':
      return 'success';
    default:
      return 'info';
  }
}

export async function registerRoutes(app: Express): Promise<Server> {
  // Create the single HTTP server instance for both Express and WebSocket
  const httpServer = createServer(app);
  
  // Initialize WebSocket server with our HTTP server
  const wss = new WebSocketServer({ server: httpServer, path: '/ws' });
  
  // Handle WebSocket connections
  wss.on('connection', (ws: WebSocket) => {
    // Add new client to the set
    clients.add(ws);
    
    // Send initial connection message
    ws.send(JSON.stringify({ 
      type: 'connection', 
      message: 'Connected to DockSafe notification system',
      timestamp: new Date().toISOString()
    }));
    
    // Handle client disconnection
    ws.on('close', () => {
      clients.delete(ws);
    });
    
    // Handle incoming messages from clients
    ws.on('message', (message) => {
      try {
        // Process incoming messages if needed
        const data = JSON.parse(message.toString());
        console.log('Received message:', data);
      } catch (error) {
        console.error('Error parsing message:', error);
      }
    });
  });
  // Docks endpoints
  app.get("/api/docks", async (_req: Request, res: Response) => {
    try {
      const docks = await storage.getAllDocks();
      res.json(docks);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch docks" });
    }
  });

  app.get("/api/docks/:id", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      const dock = await storage.getDock(id);
      
      if (!dock) {
        return res.status(404).json({ message: "Dock not found" });
      }
      
      res.json(dock);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch dock" });
    }
  });

  app.post("/api/docks", async (req: Request, res: Response) => {
    try {
      const data = insertDockSchema.parse(req.body);
      const dock = await storage.createDock(data);
      res.status(201).json(dock);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid dock data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create dock" });
    }
  });

  app.put("/api/docks/:id", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      const oldDock = await storage.getDock(id);
      const data = insertDockSchema.parse(req.body);
      const dock = await storage.updateDock(id, data);
      
      if (!dock) {
        return res.status(404).json({ message: "Dock not found" });
      }
      
      // Check if the status has changed - this needs a real-time alert
      if (oldDock && oldDock.status !== dock.status) {
        // Log the status change to activity log
        await storage.createActivityLog({
          dockId: dock.id,
          userId: 1, // Use system user ID
          type: "dock_status_change",
          message: `${dock.name} status changed from ${oldDock.status} to ${dock.status}`,
          relatedEntityId: dock.id,
          relatedEntityType: "dock",
          severity: getSeverityFromDockStatus(dock.status)
        });
        
        // Send real-time notification about the dock status change
        broadcastNotification({
          type: 'safety_alert',
          alertType: 'dock_status',
          title: `Dock Status Changed`,
          message: `${dock.name} status changed from ${oldDock.status} to ${dock.status}`,
          severity: getSeverityFromDockStatus(dock.status),
          location: dock.name,
          timestamp: new Date().toISOString(),
          dockId: dock.id
        });
      }
      
      res.json(dock);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid dock data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to update dock" });
    }
  });

  // Checklist Items endpoints
  app.get("/api/checklist-items", async (_req: Request, res: Response) => {
    try {
      const items = await storage.getAllChecklistItems();
      res.json(items);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch checklist items" });
    }
  });

  app.post("/api/checklist-items", async (req: Request, res: Response) => {
    try {
      const data = insertChecklistItemSchema.parse(req.body);
      const item = await storage.createChecklistItem(data);
      res.status(201).json(item);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid checklist item data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create checklist item" });
    }
  });

  // Completed Checklists endpoints
  app.get("/api/completed-checklists", async (_req: Request, res: Response) => {
    try {
      const checklists = await storage.getAllCompletedChecklists();
      res.json(checklists);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch completed checklists" });
    }
  });

  app.get("/api/completed-checklists/dock/:dockId", async (req: Request, res: Response) => {
    try {
      const dockId = parseInt(req.params.dockId);
      const checklists = await storage.getCompletedChecklistsByDock(dockId);
      res.json(checklists);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch completed checklists for dock" });
    }
  });

  app.post("/api/completed-checklists", async (req: Request, res: Response) => {
    try {
      const data = insertCompletedChecklistSchema.parse(req.body);
      const checklist = await storage.createCompletedChecklist(data);
      
      // Try to get dock name for better notification details
      let dockName = `Dock ${data.dockId}`;
      try {
        const dock = await storage.getDock(data.dockId);
        if (dock) {
          dockName = dock.name;
        }
      } catch (e) {
        // Continue with default dock name if we can't get the actual name
      }
      
      // Log this activity
      const activityLog = await storage.createActivityLog({
        dockId: data.dockId,
        userId: data.userId,
        type: "safety_check",
        message: `${dockName} - Safety Check ${data.allPassed ? 'Completed' : 'Failed'}`,
        relatedEntityId: checklist.id,
        relatedEntityType: "completed_checklist",
        severity: data.allPassed ? "info" : "warning"
      });
      
      // Send real-time notification to all connected clients
      broadcastNotification({
        type: 'safety_alert',
        alertType: 'checklist',
        title: `Safety Check ${data.allPassed ? 'Passed' : 'Failed'}`,
        message: `${dockName} safety inspection ${data.allPassed ? 'passed all checks' : 'failed one or more checks'}`,
        severity: data.allPassed ? 'success' : 'warning',
        location: dockName,
        timestamp: new Date().toISOString(),
        checklistId: checklist.id
      });
      
      res.status(201).json(checklist);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid completed checklist data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create completed checklist" });
    }
  });

  // Vehicles endpoints
  app.get("/api/vehicles", async (_req: Request, res: Response) => {
    try {
      const vehicles = await storage.getAllVehicles();
      res.json(vehicles);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch vehicles" });
    }
  });

  app.get("/api/vehicles/active", async (_req: Request, res: Response) => {
    try {
      const vehicles = await storage.getActiveVehicles();
      res.json(vehicles);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch active vehicles" });
    }
  });

  app.post("/api/vehicles", async (req: Request, res: Response) => {
    try {
      const data = insertVehicleSchema.parse(req.body);
      const vehicle = await storage.createVehicle(data);
      
      // Use a default system user ID if none provided in the request body
      const userId = req.body.userId || 1;
      
      // Log this activity
      const activityLog = await storage.createActivityLog({
        dockId: data.dockId,
        userId: userId,
        type: "vehicle_entry",
        message: `Vehicle ${data.trailerNumber} entered the facility`,
        relatedEntityId: vehicle.id,
        relatedEntityType: "vehicle",
        severity: "info"
      });
      
      // Send real-time notification about vehicle entry
      broadcastNotification({
        type: 'safety_alert',
        alertType: 'vehicle',
        title: 'Vehicle Entry',
        message: `Vehicle ${data.trailerNumber} has entered the facility`,
        severity: 'info',
        location: data.dockId ? `Dock ${data.dockId}` : 'Unknown',
        timestamp: new Date().toISOString(),
        vehicleId: vehicle.id
      });
      
      res.status(201).json(vehicle);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid vehicle data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create vehicle" });
    }
  });

  // Step 1: Preliminary dock assignment (office personnel)
  app.put("/api/vehicles/:id/preliminary-assign", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      const { dockId, userId = 1 } = req.body;
      
      if (!dockId) {
        return res.status(400).json({ message: "Dock ID is required" });
      }
      
      // Get the vehicle and dock
      const vehicle = await storage.getVehicle(id);
      const dock = await storage.getDock(dockId);
      
      if (!vehicle) {
        return res.status(404).json({ message: "Vehicle not found" });
      }
      
      if (!dock) {
        return res.status(404).json({ message: "Dock not found" });
      }
      
      // Check if dock is available for preliminary assignment
      if (dock.status === "in_use") {
        return res.status(400).json({ 
          message: "Cannot assign trailer to a dock that is already in use",
          errorType: "dock_in_use"
        });
      }
      
      if (dock.status === "out_of_service" || dock.status === "maintenance") {
        return res.status(400).json({ 
          message: "Cannot assign trailer to a dock that is out of service or under maintenance",
          errorType: "dock_unavailable"
        });
      }
      
      // Update the vehicle with preliminary dock assignment
      const updatedVehicle = await storage.updateVehicle(id, { 
        dockId, 
        status: 'pending_safety_check' 
      });

      if (!updatedVehicle) {
        return res.status(404).json({ message: "Failed to update vehicle" });
      }

      // Update the dock status to pending verification
      await storage.updateDock(dockId, { 
        ...dock,
        status: 'pending_verification'
      });

      // Log the activity
      await storage.createActivityLog({
        type: 'preliminary_dock_assignment',
        message: `Vehicle ${updatedVehicle.trailerNumber} preliminarily assigned to ${dock.name}. Awaiting safety check.`,
        userId,
        dockId,
        severity: 'info'
      });

      broadcastNotification({
        type: 'dock_status_change',
        dockId,
        status: 'pending_verification',
        message: `Vehicle ${updatedVehicle.trailerNumber} preliminarily assigned to dock ${dock.name}. Safety check required.`
      });

      return res.json(updatedVehicle);
    } catch (error) {
      console.error("Error making preliminary dock assignment:", error);
      return res.status(500).json({ error: "Failed to assign dock to vehicle" });
    }
  });
  
  // Step 2: Final dock assignment with safety checks (dock personnel)
  app.put("/api/vehicles/:id/assign-dock", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      const { dockId, checklistResults, userId = 1 } = req.body;
      
      if (!dockId) {
        return res.status(400).json({ message: "Dock ID is required" });
      }
      
      // Get the vehicle and dock
      const vehicle = await storage.getVehicle(id);
      const dock = await storage.getDock(dockId);
      
      if (!vehicle) {
        return res.status(404).json({ message: "Vehicle not found" });
      }
      
      if (!dock) {
        return res.status(404).json({ message: "Dock not found" });
      }
      
      // Verify the vehicle has been preliminarily assigned
      if (vehicle.status !== 'pending_safety_check') {
        return res.status(400).json({
          message: "Vehicle must be preliminarily assigned before completing safety checks",
          errorType: "invalid_vehicle_state"
        });
      }
      
      // Check if dock is available for assignment
      if (dock.status === "in_use") {
        return res.status(400).json({ 
          message: "Cannot assign trailer to a dock that is already in use",
          errorType: "dock_in_use"
        });
      }
      
      if (dock.status === "out_of_service" || dock.status === "maintenance") {
        return res.status(400).json({ 
          message: "Cannot assign trailer to a dock that is out of service or under maintenance",
          errorType: "dock_unavailable"
        });
      }
      
      let allChecklistItemsPassed = false;
      let completedChecklistId = null;
      
      // If checklist results are provided, validate and save them
      if (checklistResults) {
        // Get all checklist items to verify that all critical items have passed
        const checklistItems = await storage.getAllChecklistItems();
        const criticalItems = checklistItems.filter(item => item.isCritical);
        
        // Verify all critical items have passed
        const criticalItemIds = criticalItems.map(item => item.id);
        const providedCriticalItems = checklistResults.filter((result: any) => 
          criticalItemIds.includes(result.itemId)
        );
        
        // Check if all critical items were provided and passed
        const allCriticalPassed = providedCriticalItems.every((result: any) => result.passed);
        
        // If any critical item failed, don't allow assignment
        if (!allCriticalPassed) {
          return res.status(400).json({
            message: "Cannot assign trailer to dock - critical safety checks have failed",
            errorType: "safety_check_failed"
          });
        }
        
        // Get the percentage of passed items
        const totalPassed = checklistResults.filter((result: any) => result.passed).length;
        const passPercentage = (totalPassed / checklistResults.length) * 100;
        
        // All critical items passed
        allChecklistItemsPassed = allCriticalPassed;
        
        // Save the completed checklist
        const completedChecklist = await storage.createCompletedChecklist({
          dockId,
          userId,
          results: checklistResults,
          allPassed: allChecklistItemsPassed
        });
        
        completedChecklistId = completedChecklist.id;
        
        // Log the safety checklist completion
        await storage.createActivityLog({
          dockId,
          userId,
          type: "safety_check",
          message: `Safety checklist completed for dock ${dock.name} - ${passPercentage.toFixed(0)}% passed`,
          relatedEntityId: completedChecklist.id,
          relatedEntityType: "checklist",
          severity: allChecklistItemsPassed ? "info" : "warning"
        });
      } else {
        // No checklist results provided - require them for safety
        return res.status(400).json({
          message: "Safety checklist results are required for dock assignment",
          errorType: "missing_safety_check"
        });
      }
      
      // Update the dock status to in-use
      await storage.updateDock(dockId, {
        ...dock,
        status: "in_use"
      });
      
      // Update the vehicle with the dock assignment
      const updatedVehicle = await storage.updateVehicle(id, {
        ...vehicle,
        dockId,
        status: "assigned"
      });
      
      // Log this activity
      const activityLog = await storage.createActivityLog({
        dockId,
        userId,
        type: "dock_assignment",
        message: `Trailer ${vehicle.trailerNumber} assigned to dock ${dock.name} - Safety check ${allChecklistItemsPassed ? 'passed' : 'conditionally passed'}`,
        relatedEntityId: vehicle.id,
        relatedEntityType: "vehicle",
        severity: allChecklistItemsPassed ? "info" : "warning"
      });
      
      // Broadcast notification
      broadcastNotification({
        type: 'safety_alert',
        alertType: 'dock_status',
        title: 'Dock Assignment',
        message: `Trailer ${vehicle.trailerNumber} assigned to dock ${dock.name}`,
        severity: allChecklistItemsPassed ? 'info' : 'warning',
        dockId,
        timestamp: new Date().toISOString(),
        checklistId: completedChecklistId
      });
      
      res.status(200).json({
        ...updatedVehicle,
        checklistId: completedChecklistId,
        allChecklistItemsPassed
      });
    } catch (error) {
      console.error("Error assigning dock to vehicle:", error);
      res.status(500).json({ message: "Failed to assign dock to vehicle" });
    }
  });

  app.put("/api/vehicles/:id/exit", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      const vehicle = await storage.markVehicleExit(id);
      
      if (!vehicle) {
        return res.status(404).json({ message: "Vehicle not found" });
      }
      
      // Get a default system user ID if none provided
      const userId = req.body.userId || 1;
      
      // Log this activity
      const activityLog = await storage.createActivityLog({
        dockId: vehicle.dockId,
        userId: userId,
        type: "vehicle_exit",
        message: `Vehicle ${vehicle.trailerNumber} exited the facility`,
        relatedEntityId: vehicle.id,
        relatedEntityType: "vehicle",
        severity: "info"
      });
      
      // Send real-time notification about vehicle exit
      broadcastNotification({
        type: 'safety_alert',
        alertType: 'vehicle',
        title: 'Vehicle Exit',
        message: `Vehicle ${vehicle.trailerNumber} has exited the facility`,
        severity: 'info',
        location: vehicle.dockId ? `Dock ${vehicle.dockId}` : 'Unknown',
        timestamp: new Date().toISOString(),
        vehicleId: vehicle.id
      });
      
      res.json(vehicle);
    } catch (error) {
      res.status(500).json({ message: "Failed to mark vehicle exit" });
    }
  });

  // Incidents endpoints
  app.get("/api/incidents", async (_req: Request, res: Response) => {
    try {
      const incidents = await storage.getAllIncidents();
      res.json(incidents);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch incidents" });
    }
  });

  app.get("/api/incidents/open", async (_req: Request, res: Response) => {
    try {
      const incidents = await storage.getOpenIncidents();
      res.json(incidents);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch open incidents" });
    }
  });

  app.post("/api/incidents", async (req: Request, res: Response) => {
    try {
      const data = insertIncidentSchema.parse(req.body);
      const incident = await storage.createIncident(data);
      
      // Log this activity
      const activityLog = await storage.createActivityLog({
        dockId: data.dockId,
        userId: data.reportedBy,
        type: "incident_report",
        message: `Incident reported: ${data.title}`,
        relatedEntityId: incident.id,
        relatedEntityType: "incident",
        severity: data.severity === "critical" ? "error" : data.severity === "high" ? "warning" : "info"
      });
      
      // Send real-time notification to all connected clients
      broadcastNotification({
        type: 'safety_alert',
        alertType: 'incident',
        title: `New Incident: ${data.title}`,
        message: data.description,
        severity: data.severity,
        location: `Dock ${data.dockId ? `#${data.dockId}` : 'Unknown'}`,
        timestamp: new Date().toISOString(),
        incidentId: incident.id
      });
      
      res.status(201).json(incident);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid incident data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create incident" });
    }
  });

  // Activity Log endpoints
  app.get("/api/activity-log", async (_req: Request, res: Response) => {
    try {
      const activities = await storage.getRecentActivityLog();
      res.json(activities);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch activity log" });
    }
  });

  app.post("/api/activity-log", async (req: Request, res: Response) => {
    try {
      const data = insertActivityLogSchema.parse(req.body);
      const activity = await storage.createActivityLog(data);
      res.status(201).json(activity);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid activity log data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create activity log entry" });
    }
  });

  // Safety metrics endpoint
  app.get("/api/safety-metrics", async (_req: Request, res: Response) => {
    try {
      const metrics = await storage.getSafetyMetrics();
      res.json(metrics);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch safety metrics" });
    }
  });

  // User endpoints
  app.get("/api/users", async (_req: Request, res: Response) => {
    try {
      const users = await storage.getAllUsers();
      res.json(users);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch users" });
    }
  });
  
  // Create a new user
  app.post("/api/users", async (req: Request, res: Response) => {
    try {
      const userData = req.body;
      
      // Check if username already exists
      const existingUser = await storage.getUserByUsername(userData.username);
      if (existingUser) {
        return res.status(400).json({ message: "Username already exists" });
      }
      
      const user = await storage.createUser(userData);
      
      // Log the activity
      await storage.createActivityLog({
        userId: 1, // Admin user ID
        type: "user_created",
        message: `New user created: ${userData.username} (${userData.role})`,
        severity: "info",
      });
      
      res.status(201).json(user);
    } catch (error) {
      console.error("Error creating user:", error);
      res.status(500).json({ message: "Failed to create user" });
    }
  });
  
  // Update an existing user
  app.put("/api/users/:id", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      const userData = req.body;
      
      // Check if user exists
      const existingUser = await storage.getUser(id);
      if (!existingUser) {
        return res.status(404).json({ message: "User not found" });
      }
      
      // If username is being changed, check if the new username already exists
      if (userData.username && userData.username !== existingUser.username) {
        const userWithSameUsername = await storage.getUserByUsername(userData.username);
        if (userWithSameUsername) {
          return res.status(400).json({ message: "Username already exists" });
        }
      }
      
      const updatedUser = await storage.updateUser(id, userData);
      
      // Log the activity
      await storage.createActivityLog({
        userId: 1, // Admin user ID
        type: "user_updated",
        message: `User updated: ${updatedUser.username}`,
        severity: "info",
      });
      
      res.json(updatedUser);
    } catch (error) {
      console.error("Error updating user:", error);
      res.status(500).json({ message: "Failed to update user" });
    }
  });
  
  // Delete a user
  app.delete("/api/users/:id", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      
      // Check if user exists
      const existingUser = await storage.getUser(id);
      if (!existingUser) {
        return res.status(404).json({ message: "User not found" });
      }
      
      await storage.deleteUser(id);
      
      // Log the activity
      await storage.createActivityLog({
        userId: 1, // Admin user ID
        type: "user_deleted",
        message: `User deleted: ${existingUser.username}`,
        severity: "warning",
      });
      
      res.json({ success: true });
    } catch (error) {
      console.error("Error deleting user:", error);
      res.status(500).json({ message: "Failed to delete user" });
    }
  });

  // Initialize demo data if needed
  app.post("/api/init-demo-data", async (_req: Request, res: Response) => {
    try {
      await storage.initializeDemoData();
      res.json({ success: true, message: "Demo data initialized" });
    } catch (error) {
      res.status(500).json({ message: "Failed to initialize demo data" });
    }
  });

  return httpServer;
}
