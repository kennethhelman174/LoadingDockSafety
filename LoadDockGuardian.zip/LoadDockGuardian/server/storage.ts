import {
  type User,
  type InsertUser,
  type Dock,
  type InsertDock,
  type ChecklistItem,
  type InsertChecklistItem,
  type CompletedChecklist,
  type InsertCompletedChecklist,
  type Vehicle,
  type InsertVehicle,
  type Incident,
  type InsertIncident,
  type ActivityLogEntry,
  type InsertActivityLogEntry,
  users,
  docks,
  checklistItems,
  completedChecklists,
  vehicles,
  incidents,
  activityLog
} from "@shared/schema";
import { db } from "./db";
import { eq, desc, isNull, ne, count } from "drizzle-orm";

export interface IStorage {
  // Users
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUser(id: number, user: Partial<User>): Promise<User | undefined>;
  deleteUser(id: number): Promise<boolean>;
  getAllUsers(): Promise<User[]>;

  // Docks
  getDock(id: number): Promise<Dock | undefined>;
  getAllDocks(): Promise<Dock[]>;
  createDock(dock: InsertDock): Promise<Dock>;
  updateDock(id: number, dock: InsertDock): Promise<Dock | undefined>;

  // Checklist Items
  getChecklistItem(id: number): Promise<ChecklistItem | undefined>;
  getAllChecklistItems(): Promise<ChecklistItem[]>;
  createChecklistItem(item: InsertChecklistItem): Promise<ChecklistItem>;

  // Completed Checklists
  getCompletedChecklist(id: number): Promise<CompletedChecklist | undefined>;
  getAllCompletedChecklists(): Promise<CompletedChecklist[]>;
  getCompletedChecklistsByDock(dockId: number): Promise<CompletedChecklist[]>;
  createCompletedChecklist(checklist: InsertCompletedChecklist): Promise<CompletedChecklist>;

  // Vehicles
  getVehicle(id: number): Promise<Vehicle | undefined>;
  getAllVehicles(): Promise<Vehicle[]>;
  getActiveVehicles(): Promise<Vehicle[]>;
  createVehicle(vehicle: InsertVehicle): Promise<Vehicle>;
  updateVehicle(id: number, vehicle: Partial<Vehicle>): Promise<Vehicle | undefined>;
  markVehicleExit(id: number): Promise<Vehicle | undefined>;

  // Incidents
  getIncident(id: number): Promise<Incident | undefined>;
  getAllIncidents(): Promise<Incident[]>;
  getOpenIncidents(): Promise<Incident[]>;
  createIncident(incident: InsertIncident): Promise<Incident>;
  updateIncident(id: number, incident: Partial<InsertIncident>): Promise<Incident | undefined>;

  // Activity Log
  getActivityLogEntry(id: number): Promise<ActivityLogEntry | undefined>;
  getRecentActivityLog(limit?: number): Promise<ActivityLogEntry[]>;
  createActivityLog(entry: InsertActivityLogEntry): Promise<ActivityLogEntry>;

  // Safety Metrics
  getSafetyMetrics(): Promise<{
    daysSinceLastIncident: number;
    safetyScore: number;
    checklistCompletionRate: number;
    previousRecord: number;
  }>;

  // Demo data initialization
  initializeDemoData(): Promise<void>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private docks: Map<number, Dock>;
  private checklistItems: Map<number, ChecklistItem>;
  private completedChecklists: Map<number, CompletedChecklist>;
  private vehicles: Map<number, Vehicle>;
  private incidents: Map<number, Incident>;
  private activityLog: Map<number, ActivityLogEntry>;

  private userCurrentId: number;
  private dockCurrentId: number;
  private checklistItemCurrentId: number;
  private completedChecklistCurrentId: number;
  private vehicleCurrentId: number;
  private incidentCurrentId: number;
  private activityLogCurrentId: number;

  constructor() {
    this.users = new Map();
    this.docks = new Map();
    this.checklistItems = new Map();
    this.completedChecklists = new Map();
    this.vehicles = new Map();
    this.incidents = new Map();
    this.activityLog = new Map();

    this.userCurrentId = 1;
    this.dockCurrentId = 1;
    this.checklistItemCurrentId = 1;
    this.completedChecklistCurrentId = 1;
    this.vehicleCurrentId = 1;
    this.incidentCurrentId = 1;
    this.activityLogCurrentId = 1;

    // Initialize with a default user
    this.createUser({
      username: "operator",
      password: "password",
      name: "John Operator",
      role: "operator"
    });
  }

  // User methods
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.userCurrentId++;
    const now = new Date();
    
    // Ensure required fields have default values
    const user: User = { 
      ...insertUser, 
      id,
      role: insertUser.role || "operator",
      isActive: insertUser.isActive !== undefined ? insertUser.isActive : true,
      email: insertUser.email || null,
      phone: insertUser.phone || null,
      department: insertUser.department || null,
      lastLogin: null,
      createdAt: now
    };
    
    this.users.set(id, user);
    return user;
  }
  
  async updateUser(id: number, updateData: Partial<User>): Promise<User | undefined> {
    const existingUser = await this.getUser(id);
    if (!existingUser) {
      return undefined;
    }
    
    // Create updated user object
    const updatedUser: User = {
      ...existingUser,
      ...updateData,
      // Don't allow updating the ID
      id: existingUser.id
    };
    
    this.users.set(id, updatedUser);
    return updatedUser;
  }
  
  async deleteUser(id: number): Promise<boolean> {
    const exists = this.users.has(id);
    if (exists) {
      this.users.delete(id);
      return true;
    }
    return false;
  }

  async getAllUsers(): Promise<User[]> {
    return Array.from(this.users.values());
  }

  // Dock methods
  async getDock(id: number): Promise<Dock | undefined> {
    return this.docks.get(id);
  }

  async getAllDocks(): Promise<Dock[]> {
    return Array.from(this.docks.values());
  }

  async createDock(insertDock: InsertDock): Promise<Dock> {
    const id = this.dockCurrentId++;
    const dock: Dock = { ...insertDock, id };
    this.docks.set(id, dock);
    return dock;
  }

  async updateDock(id: number, updateDock: InsertDock): Promise<Dock | undefined> {
    const existingDock = this.docks.get(id);
    if (!existingDock) return undefined;
    
    const updatedDock: Dock = { ...updateDock, id };
    this.docks.set(id, updatedDock);
    return updatedDock;
  }

  // Checklist Item methods
  async getChecklistItem(id: number): Promise<ChecklistItem | undefined> {
    return this.checklistItems.get(id);
  }

  async getAllChecklistItems(): Promise<ChecklistItem[]> {
    return Array.from(this.checklistItems.values())
      .sort((a, b) => a.sortOrder - b.sortOrder);
  }

  async createChecklistItem(insertItem: InsertChecklistItem): Promise<ChecklistItem> {
    const id = this.checklistItemCurrentId++;
    const item: ChecklistItem = { ...insertItem, id };
    this.checklistItems.set(id, item);
    return item;
  }

  // Completed Checklist methods
  async getCompletedChecklist(id: number): Promise<CompletedChecklist | undefined> {
    return this.completedChecklists.get(id);
  }

  async getAllCompletedChecklists(): Promise<CompletedChecklist[]> {
    return Array.from(this.completedChecklists.values());
  }

  async getCompletedChecklistsByDock(dockId: number): Promise<CompletedChecklist[]> {
    return Array.from(this.completedChecklists.values())
      .filter(checklist => checklist.dockId === dockId)
      .sort((a, b) => new Date(b.completedAt).getTime() - new Date(a.completedAt).getTime());
  }

  async createCompletedChecklist(insertChecklist: InsertCompletedChecklist): Promise<CompletedChecklist> {
    const id = this.completedChecklistCurrentId++;
    const checklist: CompletedChecklist = {
      ...insertChecklist,
      id,
      completedAt: new Date(),
    };
    this.completedChecklists.set(id, checklist);
    return checklist;
  }

  // Vehicle methods
  async getVehicle(id: number): Promise<Vehicle | undefined> {
    return this.vehicles.get(id);
  }

  async getAllVehicles(): Promise<Vehicle[]> {
    return Array.from(this.vehicles.values());
  }

  async getActiveVehicles(): Promise<Vehicle[]> {
    return Array.from(this.vehicles.values())
      .filter(vehicle => !vehicle.exitTime)
      .sort((a, b) => new Date(b.entryTime).getTime() - new Date(a.entryTime).getTime());
  }

  async createVehicle(insertVehicle: InsertVehicle): Promise<Vehicle> {
    const id = this.vehicleCurrentId++;
    const vehicle: Vehicle = {
      ...insertVehicle,
      id,
      entryTime: new Date(),
      exitTime: null,
    };
    this.vehicles.set(id, vehicle);
    return vehicle;
  }

  async updateVehicle(id: number, updateData: Partial<Vehicle>): Promise<Vehicle | undefined> {
    const vehicle = this.vehicles.get(id);
    if (!vehicle) return undefined;
    
    const updatedVehicle: Vehicle = {
      ...vehicle,
      ...updateData,
    };
    this.vehicles.set(id, updatedVehicle);
    return updatedVehicle;
  }

  async markVehicleExit(id: number): Promise<Vehicle | undefined> {
    const vehicle = this.vehicles.get(id);
    if (!vehicle) return undefined;
    
    const updatedVehicle: Vehicle = {
      ...vehicle,
      exitTime: new Date(),
      status: "complete",
      dockId: null,
    };
    this.vehicles.set(id, updatedVehicle);
    return updatedVehicle;
  }

  // Incident methods
  async getIncident(id: number): Promise<Incident | undefined> {
    return this.incidents.get(id);
  }

  async getAllIncidents(): Promise<Incident[]> {
    return Array.from(this.incidents.values())
      .sort((a, b) => new Date(b.reportedAt).getTime() - new Date(a.reportedAt).getTime());
  }

  async getOpenIncidents(): Promise<Incident[]> {
    return Array.from(this.incidents.values())
      .filter(incident => incident.status !== "resolved")
      .sort((a, b) => new Date(b.reportedAt).getTime() - new Date(a.reportedAt).getTime());
  }

  async createIncident(insertIncident: InsertIncident): Promise<Incident> {
    const id = this.incidentCurrentId++;
    const incident: Incident = {
      ...insertIncident,
      id,
      reportedAt: new Date(),
      resolvedAt: null,
    };
    this.incidents.set(id, incident);
    return incident;
  }

  async updateIncident(id: number, updateData: Partial<InsertIncident>): Promise<Incident | undefined> {
    const incident = this.incidents.get(id);
    if (!incident) return undefined;
    
    const updatedIncident: Incident = {
      ...incident,
      ...updateData,
    };
    
    if (updateData.status === "resolved" && incident.status !== "resolved") {
      updatedIncident.resolvedAt = new Date();
    }
    
    this.incidents.set(id, updatedIncident);
    return updatedIncident;
  }

  // Activity Log methods
  async getActivityLogEntry(id: number): Promise<ActivityLogEntry | undefined> {
    return this.activityLog.get(id);
  }

  async getRecentActivityLog(limit: number = 10): Promise<ActivityLogEntry[]> {
    return Array.from(this.activityLog.values())
      .sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime())
      .slice(0, limit);
  }

  async createActivityLog(insertEntry: InsertActivityLogEntry): Promise<ActivityLogEntry> {
    const id = this.activityLogCurrentId++;
    const entry: ActivityLogEntry = {
      ...insertEntry,
      id,
      timestamp: new Date(),
    };
    this.activityLog.set(id, entry);
    return entry;
  }

  // Safety Metrics
  async getSafetyMetrics(): Promise<{
    daysSinceLastIncident: number;
    safetyScore: number;
    checklistCompletionRate: number;
    previousRecord: number;
  }> {
    // Calculate days since last incident
    const incidents = Array.from(this.incidents.values());
    let daysSinceLastIncident = 23; // Default for demo
    
    if (incidents.length > 0) {
      const sortedIncidents = incidents.sort(
        (a, b) => new Date(b.reportedAt).getTime() - new Date(a.reportedAt).getTime()
      );
      const latestIncident = sortedIncidents[0];
      
      if (latestIncident) {
        const incidentDate = new Date(latestIncident.reportedAt);
        const today = new Date();
        const diffTime = Math.abs(today.getTime() - incidentDate.getTime());
        daysSinceLastIncident = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
      }
    }
    
    // Calculate checklist completion rate
    const docks = Array.from(this.docks.values());
    const completedChecklists = Array.from(this.completedChecklists.values());
    
    // For demo, return default values if not enough data
    return {
      daysSinceLastIncident,
      safetyScore: 92,
      checklistCompletionRate: 87,
      previousRecord: 45
    };
  }

  // Initialize demo data
  async initializeDemoData(): Promise<void> {
    // Create default user if not exists
    if (this.users.size === 0) {
      await this.createUser({
        username: "operator",
        password: "password",
        name: "John Operator",
        role: "operator"
      });
    }
    
    // Create docks
    const dockNames = ["Dock 1", "Dock 2", "Dock 3", "Dock 4"];
    const dockStatuses = ["in_use", "in_use", "danger", "available"];
    
    for (let i = 0; i < dockNames.length; i++) {
      await this.createDock({
        name: dockNames[i],
        status: dockStatuses[i],
        lastInspectionDate: new Date(),
        notes: i === 2 ? "Restraint system failure" : ""
      });
    }
    
    // Create checklist items
    const checklistItems = [
      { text: "Trailer restraint engaged", description: "Verify physical lock with visual inspection", isCritical: true, sortOrder: 1 },
      { text: "Wheel chocks properly placed", description: "Both sides of trailer have wheel chocks", isCritical: true, sortOrder: 2 },
      { text: "Warning lights functioning", description: "Red/green signal lights work properly", isCritical: false, sortOrder: 3 },
      { text: "Dock leveler properly positioned", description: "Level is secure with no gaps or trip hazards", isCritical: true, sortOrder: 4 },
      { text: "Trailer door fully open & secured", description: "Doors locked in open position", isCritical: false, sortOrder: 5 }
    ];
    
    for (const item of checklistItems) {
      await this.createChecklistItem(item);
    }
    
    // Create vehicles
    const vehicles = [
      { trailerNumber: "TRL-45672", driverName: "Michael Smith", company: "Fast Logistics", dockId: 1, status: "loading" },
      { trailerNumber: "TRL-89023", driverName: "Robert Johnson", company: "Swift Carriers", dockId: 2, status: "unloading" }
    ];
    
    for (const vehicle of vehicles) {
      await this.createVehicle(vehicle);
    }
    
    // Create incident for dock 3
    await this.createIncident({
      dockId: 3,
      title: "Restraint System Failure",
      description: "Dock 3 restraint failure detected during morning inspection.",
      reportedBy: 1,
      severity: "critical",
      status: "open",
      resolutionNotes: "Maintenance has been notified. Do not use until resolved."
    });
    
    // Create activity logs
    const activities = [
      { dockId: 1, userId: 1, type: "safety_check", message: "Dock 1 - Safety Check Completed", severity: "info" },
      { dockId: 2, userId: 1, type: "safety_check", message: "Dock 2 - Partial Restraint Engagement", severity: "warning" },
      { dockId: 3, userId: 1, type: "incident_report", message: "Dock 3 - Restraint System Failure", severity: "error" },
      { dockId: 4, userId: 1, type: "vehicle_exit", message: "Dock 4 - Trailer Departure", severity: "info" }
    ];
    
    for (const activity of activities) {
      await this.createActivityLog(activity);
    }
  }
}

export class DatabaseStorage implements IStorage {
  // Users
  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user || undefined;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user || undefined;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    // Ensure role is set or default to 'operator'
    const userToInsert = {
      ...insertUser,
      role: insertUser.role || 'operator'
    };
    
    const [user] = await db.insert(users).values(userToInsert).returning();
    return user;
  }
  
  async updateUser(id: number, updateData: Partial<User>): Promise<User | undefined> {
    // Check if user exists
    const existingUser = await this.getUser(id);
    if (!existingUser) {
      return undefined;
    }
    
    // Update user data
    const [updatedUser] = await db
      .update(users)
      .set({
        ...updateData,
        // Don't allow updating the ID
        id: id
      })
      .where(eq(users.id, id))
      .returning();
    
    return updatedUser;
  }
  
  async deleteUser(id: number): Promise<boolean> {
    // Check if user exists
    const existingUser = await this.getUser(id);
    if (!existingUser) {
      return false;
    }
    
    // Delete the user
    const result = await db
      .delete(users)
      .where(eq(users.id, id))
      .returning();
    
    return result.length > 0;
  }

  async getAllUsers(): Promise<User[]> {
    return await db.select().from(users);
  }

  // Docks
  async getDock(id: number): Promise<Dock | undefined> {
    const [dock] = await db.select().from(docks).where(eq(docks.id, id));
    return dock || undefined;
  }

  async getAllDocks(): Promise<Dock[]> {
    return await db.select().from(docks);
  }

  async createDock(insertDock: InsertDock): Promise<Dock> {
    const [dock] = await db.insert(docks).values(insertDock).returning();
    return dock;
  }

  async updateDock(id: number, updateDock: InsertDock): Promise<Dock | undefined> {
    const [updatedDock] = await db
      .update(docks)
      .set(updateDock)
      .where(eq(docks.id, id))
      .returning();
    return updatedDock || undefined;
  }

  // Checklist Items
  async getChecklistItem(id: number): Promise<ChecklistItem | undefined> {
    const [item] = await db.select().from(checklistItems).where(eq(checklistItems.id, id));
    return item || undefined;
  }

  async getAllChecklistItems(): Promise<ChecklistItem[]> {
    return await db.select().from(checklistItems).orderBy(checklistItems.sortOrder);
  }

  async createChecklistItem(insertItem: InsertChecklistItem): Promise<ChecklistItem> {
    const [item] = await db.insert(checklistItems).values(insertItem).returning();
    return item;
  }

  // Completed Checklists
  async getCompletedChecklist(id: number): Promise<CompletedChecklist | undefined> {
    const [checklist] = await db.select().from(completedChecklists).where(eq(completedChecklists.id, id));
    return checklist || undefined;
  }

  async getAllCompletedChecklists(): Promise<CompletedChecklist[]> {
    return await db.select().from(completedChecklists).orderBy(desc(completedChecklists.completedAt));
  }

  async getCompletedChecklistsByDock(dockId: number): Promise<CompletedChecklist[]> {
    return await db
      .select()
      .from(completedChecklists)
      .where(eq(completedChecklists.dockId, dockId))
      .orderBy(desc(completedChecklists.completedAt));
  }

  async createCompletedChecklist(insertChecklist: InsertCompletedChecklist): Promise<CompletedChecklist> {
    const [checklist] = await db.insert(completedChecklists).values(insertChecklist).returning();
    return checklist;
  }

  // Vehicles
  async getVehicle(id: number): Promise<Vehicle | undefined> {
    const [vehicle] = await db.select().from(vehicles).where(eq(vehicles.id, id));
    return vehicle || undefined;
  }

  async getAllVehicles(): Promise<Vehicle[]> {
    return await db.select().from(vehicles).orderBy(desc(vehicles.entryTime));
  }

  async getActiveVehicles(): Promise<Vehicle[]> {
    return await db
      .select()
      .from(vehicles)
      .where(isNull(vehicles.exitTime))
      .orderBy(desc(vehicles.entryTime));
  }

  async createVehicle(insertVehicle: InsertVehicle): Promise<Vehicle> {
    const [vehicle] = await db.insert(vehicles).values(insertVehicle).returning();
    return vehicle;
  }

  async updateVehicle(id: number, updateData: Partial<Vehicle>): Promise<Vehicle | undefined> {
    const [updatedVehicle] = await db
      .update(vehicles)
      .set(updateData)
      .where(eq(vehicles.id, id))
      .returning();
    return updatedVehicle || undefined;
  }

  async markVehicleExit(id: number): Promise<Vehicle | undefined> {
    const [updatedVehicle] = await db
      .update(vehicles)
      .set({
        exitTime: new Date(),
        status: "complete",
        dockId: null
      })
      .where(eq(vehicles.id, id))
      .returning();
    return updatedVehicle || undefined;
  }

  // Incidents
  async getIncident(id: number): Promise<Incident | undefined> {
    const [incident] = await db.select().from(incidents).where(eq(incidents.id, id));
    return incident || undefined;
  }

  async getAllIncidents(): Promise<Incident[]> {
    return await db.select().from(incidents).orderBy(desc(incidents.reportedAt));
  }

  async getOpenIncidents(): Promise<Incident[]> {
    return await db
      .select()
      .from(incidents)
      .where(ne(incidents.status, "resolved"))
      .orderBy(desc(incidents.reportedAt));
  }

  async createIncident(insertIncident: InsertIncident): Promise<Incident> {
    const [incident] = await db.insert(incidents).values(insertIncident).returning();
    return incident;
  }

  async updateIncident(id: number, updateData: Partial<InsertIncident>): Promise<Incident | undefined> {
    const dataToUpdate: any = { ...updateData };
    
    // If status is being updated to resolved, also set the resolvedAt timestamp
    if (updateData.status === "resolved") {
      dataToUpdate.resolvedAt = new Date();
    }
    
    const [updatedIncident] = await db
      .update(incidents)
      .set(dataToUpdate)
      .where(eq(incidents.id, id))
      .returning();
    return updatedIncident || undefined;
  }

  // Activity Log
  async getActivityLogEntry(id: number): Promise<ActivityLogEntry | undefined> {
    const [entry] = await db.select().from(activityLog).where(eq(activityLog.id, id));
    return entry || undefined;
  }

  async getRecentActivityLog(limit: number = 10): Promise<ActivityLogEntry[]> {
    return await db
      .select()
      .from(activityLog)
      .orderBy(desc(activityLog.timestamp))
      .limit(limit);
  }

  async createActivityLog(insertEntry: InsertActivityLogEntry): Promise<ActivityLogEntry> {
    const [entry] = await db.insert(activityLog).values(insertEntry).returning();
    return entry;
  }

  // Safety Metrics
  async getSafetyMetrics(): Promise<{
    daysSinceLastIncident: number;
    safetyScore: number;
    checklistCompletionRate: number;
    previousRecord: number;
  }> {
    // Get the latest incident date
    const [latestIncident] = await db
      .select()
      .from(incidents)
      .where(eq(incidents.severity, "high"))
      .orderBy(desc(incidents.reportedAt))
      .limit(1);
    
    // Calculate days since last incident
    let daysSinceLastIncident = 1; // Default to 1 day
    if (latestIncident) {
      const incidentDate = new Date(latestIncident.reportedAt);
      const today = new Date();
      const diffTime = Math.abs(today.getTime() - incidentDate.getTime());
      daysSinceLastIncident = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    }
      
    // Count completed checklists for the completion rate
    const [totalChecklists] = await db.select({ count: count() }).from(completedChecklists);
    const [passedChecklists] = await db
      .select({ count: count() })
      .from(completedChecklists)
      .where(eq(completedChecklists.allPassed, true));
    
    let checklistCompletionRate = 0;
    if (totalChecklists && totalChecklists.count > 0) {
      checklistCompletionRate = Math.round((passedChecklists.count / totalChecklists.count) * 100);
    } else {
      checklistCompletionRate = 87; // Default demo value
    }
    
    // For simplicity, we'll use some predefined values for these metrics
    // In a real implementation, these would be calculated based on actual data
    const safetyScore = 92;
    const previousRecord = 45;
    
    return {
      daysSinceLastIncident,
      safetyScore,
      checklistCompletionRate,
      previousRecord,
    };
  }

  // Demo data initialization
  async initializeDemoData(): Promise<void> {
    // First, check if we already have data in the tables
    const [existingUsersCount] = await db.select({ count: count() }).from(users);
    if (existingUsersCount && existingUsersCount.count > 0) {
      // Data already exists, skip initialization
      return;
    }

    // Create users
    await this.createUser({
      username: "admin",
      password: "password", // In a real app, this would be hashed
      name: "Admin User",
      role: "admin",
    });

    await this.createUser({
      username: "operator",
      password: "password", // In a real app, this would be hashed
      name: "John Operator",
      role: "operator",
    });

    // Create docks
    const dockNames = ["Dock 1", "Dock 2", "Dock 3", "Dock 4"];
    const dockStatuses = ["in_use", "in_use", "danger", "available"];
    
    for (let i = 0; i < dockNames.length; i++) {
      await this.createDock({
        name: dockNames[i],
        status: dockStatuses[i],
        lastInspectionDate: new Date(),
        notes: i === 2 ? "Restraint system failure" : ""
      });
    }
    
    // Create checklist items
    const checklistItems = [
      { text: "Trailer restraint engaged", description: "Verify physical lock with visual inspection", isCritical: true, sortOrder: 1 },
      { text: "Wheel chocks properly placed", description: "Both sides of trailer have wheel chocks", isCritical: true, sortOrder: 2 },
      { text: "Warning lights functioning", description: "Red/green signal lights work properly", isCritical: false, sortOrder: 3 },
      { text: "Dock leveler properly positioned", description: "Level is secure with no gaps or trip hazards", isCritical: true, sortOrder: 4 },
      { text: "Trailer door fully open & secured", description: "Doors locked in open position", isCritical: false, sortOrder: 5 }
    ];
    
    for (const item of checklistItems) {
      await this.createChecklistItem(item);
    }
    
    // Create vehicles
    const vehicles = [
      { trailerNumber: "TRL-45672", driverName: "Michael Smith", company: "Fast Logistics", dockId: 1, status: "loading" },
      { trailerNumber: "TRL-89023", driverName: "Robert Johnson", company: "Swift Carriers", dockId: 2, status: "unloading" }
    ];
    
    for (const vehicle of vehicles) {
      await this.createVehicle(vehicle);
    }
    
    // Create incident for dock 3
    await this.createIncident({
      dockId: 3,
      title: "Restraint System Failure",
      description: "Dock 3 restraint failure detected during morning inspection.",
      reportedBy: 1,
      severity: "critical",
      status: "open",
      resolutionNotes: "Maintenance has been notified. Do not use until resolved."
    });
    
    // Create activity logs
    const activities = [
      { dockId: 1, userId: 1, type: "safety_check", message: "Dock 1 - Safety Check Completed", severity: "info" },
      { dockId: 2, userId: 1, type: "safety_check", message: "Dock 2 - Partial Restraint Engagement", severity: "warning" },
      { dockId: 3, userId: 1, type: "incident_report", message: "Dock 3 - Restraint System Failure", severity: "error" },
      { dockId: 4, userId: 1, type: "vehicle_exit", message: "Dock 4 - Trailer Departure", severity: "info" }
    ];
    
    for (const activity of activities) {
      await this.createActivityLog(activity);
    }
  }
}

// Replace MemStorage with DatabaseStorage for production use
export const storage = new DatabaseStorage();
